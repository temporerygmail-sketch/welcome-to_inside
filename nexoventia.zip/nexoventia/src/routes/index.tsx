import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BarChart3, Lock, MessagesSquare, Radio, ShieldCheck } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { InstallButton } from "@/components/InstallButton";
import { SectionCounter } from "@/components/SectionCounter";
import { ROADMAP } from "@/lib/roadmap";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nexoventia — Roadmap 2K27 Trading Journal & Community" },
      { name: "description", content: "A 13-month trading roadmap, daily locked journal, live Quotex & Forex signals and a private trading community." },
      { property: "og:title", content: "Nexoventia — Roadmap 2K27" },
      { property: "og:description", content: "13-month trading roadmap, live signals and a private community." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const SECTIONS = ["intro", "roadmap", "signals", "community"];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <SectionCounter ids={SECTIONS} />
      <header className="fixed inset-x-0 top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Logo />
          <div className="flex items-center gap-2">
            <span className="hidden sm:block"><InstallButton variant="ghost" /></span>
            <Button asChild size="sm"><Link to="/auth">Sign in</Link></Button>
          </div>
        </div>
      </header>

      {/* 01 */}
      <section id="intro" className="relative flex min-h-screen items-end overflow-hidden pb-20 pt-32">
        <img src={hero} alt="Trading desk with gold candlestick charts" width={1600} height={912} className="absolute inset-0 h-full w-full object-cover opacity-45" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/10" />
        <div className="relative mx-auto w-full max-w-6xl px-4">
          <p className="num mb-5 text-xs uppercase tracking-[0.3em] text-gold">01 — Roadmap 2K27</p>
          <h1 className="max-w-3xl text-4xl font-bold leading-[1.05] sm:text-6xl md:text-7xl">
            From <span className="text-gold-gradient">$10</span> to a funded portfolio, one locked day at a time.
          </h1>
          <p className="mt-6 max-w-xl text-base text-muted-foreground sm:text-lg">
            Nexoventia is the private desk for a 13-month plan: daily targets, funded accounts, live signals and the team that runs them.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" className="bg-gold-gradient shadow-gold"><Link to="/auth" search={{ mode: "signup" }}>Join Nexoventia <ArrowRight className="size-4" /></Link></Button>
            <InstallButton />
          </div>
        </div>
      </section>

      {/* 02 */}
      <section id="roadmap" className="relative bg-grid py-28">
        <div className="mx-auto max-w-6xl px-4">
          <p className="num text-xs uppercase tracking-[0.3em] text-gold">02 — The plan</p>
          <h2 className="mt-3 text-3xl font-bold sm:text-5xl">13 months. Every day written out.</h2>
          <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
            {ROADMAP.map((m) => (
              <div key={m.n} className="bg-surface p-5">
                <div className="num text-xs text-muted-foreground">M{String(m.n).padStart(2, "0")}</div>
                <div className="mt-2 font-display font-semibold">{m.title.split("—")[1]?.trim()}</div>
                <div className="num mt-3 text-sm text-gold">≈ ${m.cumulative.toLocaleString()}</div>
              </div>
            ))}
            <div className="flex items-center gap-3 bg-surface p-5 text-sm text-muted-foreground">
              <Lock className="size-5 text-gold" /> Each task locks forever once ticked.
            </div>
            <div className="flex items-center gap-3 bg-surface p-5 text-sm text-muted-foreground">
              <ShieldCheck className="size-5 text-gold" /> Projections, not promises.
            </div>
            <div className="flex items-center gap-3 bg-surface p-5 text-sm text-muted-foreground">
              <BarChart3 className="size-5 text-gold" /> Planned vs actual charts.
            </div>
          </div>
        </div>
      </section>

      {/* 03 */}
      <section id="signals" className="relative py-28">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,var(--gold-soft),transparent_60%)]" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-4 md:grid-cols-2 md:items-center">
          <div>
            <p className="num text-xs uppercase tracking-[0.3em] text-gold">03 — Signals</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-5xl">Quotex & Forex signals, scored live.</h2>
            <p className="mt-5 text-muted-foreground">Every signal is tracked: wins and losses on Quotex, TP and SL hits in pips on Forex — daily, weekly, monthly and yearly. No links, no fake screenshots.</p>
          </div>
          <div className="panel p-6">
            {[
              ["EUR/USD", "BUY", "TP +32 pips", "text-success"],
              ["GBP/JPY", "SELL", "Active", "text-gold"],
              ["Quotex · AUD/CAD", "CALL 1m", "WIN", "text-success"],
              ["XAU/USD", "BUY", "SL −18 pips", "text-destructive"],
            ].map(([p, d, s, c]) => (
              <div key={p} className="flex items-center justify-between border-b border-border py-3 last:border-0">
                <div>
                  <div className="font-medium">{p}</div>
                  <div className="num text-xs text-muted-foreground">{d}</div>
                </div>
                <div className={`num text-sm font-semibold ${c}`}>{s}</div>
              </div>
            ))}
            <p className="mt-3 text-xs text-muted-foreground">Example preview</p>
          </div>
        </div>
      </section>

      {/* 04 */}
      <section id="community" className="bg-surface py-28">
        <div className="mx-auto max-w-6xl px-4">
          <p className="num text-xs uppercase tracking-[0.3em] text-gold">04 — Community</p>
          <h2 className="mt-3 max-w-2xl text-3xl font-bold sm:text-5xl">A desk, not a group chat.</h2>
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              [Radio, "Broadcast channels", "Signals and updates posted by the founder only — clean, readable, no noise."],
              [MessagesSquare, "Discussion, feedback & complaints", "Open rooms with images, video, voice notes and emojis."],
              [ShieldCheck, "Private line to the founder", "Members can message the founder directly. No spam between members."],
            ].map(([Icon, t, d]) => {
              const I = Icon as typeof Radio;
              return (
                <div key={t as string} className="panel p-6">
                  <I className="size-6 text-gold" />
                  <h3 className="mt-4 text-lg font-semibold">{t as string}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{d as string}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-14 flex flex-col items-start justify-between gap-6 rounded-2xl border border-gold/30 bg-gold-soft p-8 md:flex-row md:items-center">
            <div>
              <h3 className="text-2xl font-bold">Ready to join?</h3>
              <p className="mt-1 text-muted-foreground">Team members: have your access code ready.</p>
            </div>
            <Button asChild size="lg" className="bg-gold-gradient"><Link to="/auth" search={{ mode: "signup" }}>Create account</Link></Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-xs text-muted-foreground sm:flex-row">
          <Logo size={28} />
          <p>Trading involves risk. Figures are personal plans and projections, not financial advice.</p>
        </div>
      </footer>
    </div>
  );
}
