import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password — Nexoventia" },
      { name: "description", content: "Set a new password for your Nexoventia account." },
      { property: "og:title", content: "Reset password — Nexoventia" },
      { property: "og:description", content: "Set a new Nexoventia password." },
    ],
  }),
  component: Reset,
});

function Reset() {
  const [pw, setPw] = useState("");
  const navigate = useNavigate();
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form
        className="panel w-full max-w-sm space-y-4 p-6"
        onSubmit={async (e) => {
          e.preventDefault();
          if (pw.length < 8) return void toast.error("Password min 8 chars");
          const { error } = await supabase.auth.updateUser({ password: pw });
          if (error) return void toast.error(error.message);
          toast.success("Password updated");
          navigate({ to: "/dashboard" });
        }}
      >
        <Logo />
        <h1 className="text-xl font-bold">Set a new password</h1>
        <div className="space-y-2"><Label htmlFor="pw">New password</Label><Input id="pw" type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
        <Button className="w-full" type="submit">Update password</Button>
      </form>
    </div>
  );
}
