import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/hooks/use-me";
import { ChatRoom } from "@/components/ChatRoom";
import { PageHeader } from "@/components/PageHeader";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/messages")({
  head: () => ({ meta: [{ title: "Messages — Nexoventia" }, { name: "description", content: "Private messages with the founder." }] }),
  component: Messages,
});

function Messages() {
  const { data: me } = useMe();
  if (!me) return null;
  return me.role === "admin" ? <AdminInbox /> : <MemberChat />;
}

function MemberChat() {
  const { data: adminId } = useQuery({ queryKey: ["admin-id"], queryFn: async () => (await supabase.rpc("admin_id")).data as string | null });
  return (
    <div>
      <PageHeader eyebrow="Private" title="Message the founder" />
      {adminId ? <ChatRoom source={{ kind: "dm", peerId: adminId }} canPost /> : <p className="text-sm text-muted-foreground">The founder account isn't set up yet.</p>}
    </div>
  );
}

function AdminInbox() {
  const [peer, setPeer] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const { data: me } = useMe();
  const { data: users = [] } = useQuery({
    queryKey: ["inbox-users"],
    queryFn: async () => {
      const [{ data: profiles }, { data: dms }] = await Promise.all([
        supabase.from("profiles").select("id, username, first_name, last_name, email").neq("id", me!.id),
        supabase.from("direct_messages").select("sender_id, recipient_id, created_at").order("created_at", { ascending: false }).limit(1000),
      ]);
      const last: Record<string, string> = {};
      (dms ?? []).forEach((d) => {
        const other = d.sender_id === me!.id ? d.recipient_id : d.sender_id;
        if (!last[other]) last[other] = d.created_at;
      });
      return (profiles ?? []).map((p) => ({ ...p, last: last[p.id] ?? "" })).sort((a, b) => b.last.localeCompare(a.last));
    },
  });
  const list = users.filter((u) => `${u.username} ${u.first_name} ${u.last_name} ${u.email}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <PageHeader eyebrow="Founder" title="Inbox" />
      <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
        <div className={`panel flex max-h-[calc(100dvh-9rem)] flex-col ${peer ? "hidden lg:flex" : ""}`}>
          <div className="relative border-b border-border p-3">
            <Search className="absolute left-5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search members" className="pl-8" />
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            {list.map((u) => (
              <button key={u.id} onClick={() => setPeer(u.id)} className={`w-full rounded-lg px-3 py-2 text-left text-sm ${peer === u.id ? "bg-secondary" : "hover:bg-secondary/60"}`}>
                <div className="font-medium">{u.username ?? u.first_name ?? u.email}</div>
                <div className="truncate text-xs text-muted-foreground">{u.last ? "Has messages" : u.email}</div>
              </button>
            ))}
          </div>
        </div>
        {peer ? (
          <div>
            <button className="mb-2 text-xs text-gold lg:hidden" onClick={() => setPeer(null)}>← Back</button>
            <ChatRoom key={peer} source={{ kind: "dm", peerId: peer }} canPost />
          </div>
        ) : (
          <div className="panel hidden items-center justify-center text-sm text-muted-foreground lg:flex">Select a member to start chatting.</div>
        )}
      </div>
    </div>
  );
}
