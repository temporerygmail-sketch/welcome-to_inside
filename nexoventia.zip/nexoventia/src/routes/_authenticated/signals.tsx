import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { SignalRow, SignalStats, useSignals } from "@/components/SignalStats";

export const Route = createFileRoute("/_authenticated/signals")({
  head: () => ({ meta: [{ title: "Signal stats — Nexoventia" }, { name: "description", content: "Quotex and Forex signal performance." }] }),
  component: SignalsPage,
});

function SignalsPage() {
  const { data = [] } = useSignals();
  const [market, setMarket] = useState<"all" | "quotex" | "forex">("all");
  const list = data.filter((s) => market === "all" || s.market === market);
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Live" title="Signal stats" />
      <SignalStats />
      <section className="panel p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Signal history</h2>
          <div className="flex gap-1 text-xs">
            {(["all", "quotex", "forex"] as const).map((m) => (
              <button key={m} onClick={() => setMarket(m)} className={`rounded-md px-3 py-1.5 capitalize ${market === m ? "bg-primary text-primary-foreground" : "bg-secondary"}`}>{m}</button>
            ))}
          </div>
        </div>
        {list.length === 0 ? <p className="text-sm text-muted-foreground">No signals yet.</p> : list.map((s) => <SignalRow key={s.id} s={s} />)}
      </section>
    </div>
  );
}
