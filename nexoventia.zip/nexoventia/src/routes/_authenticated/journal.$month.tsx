import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { format } from "date-fns";
import { toast } from "sonner";
import { CheckCircle2, ChevronLeft, ChevronRight, Circle, Coffee, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ROADMAP, ACCOUNTS, dayFromStart, type Task } from "@/lib/roadmap";
import { useCompletions } from "@/hooks/use-completions";
import { useMe, useSettings } from "@/hooks/use-me";
import { PageHeader } from "@/components/PageHeader";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/journal/$month")({
  loader: ({ params }) => {
    const m = ROADMAP[Number(params.month) - 1];
    if (!m) throw notFound();
    return { n: m.n, title: m.title };
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? "Month"} — Nexoventia` }, { name: "description", content: "Monthly roadmap detail." }] }),
  component: MonthPage,
});

function MonthPage() {
  const { n } = Route.useLoaderData();
  const m = ROADMAP[n - 1]!;
  const { data: me } = useMe();
  const { data: comps = {} } = useCompletions();
  const { data: settings } = useSettings();
  const cur = settings ? dayFromStart(settings.roadmap_start) : null;
  const [ticking, setTicking] = useState<Task | null>(null);
  const [balance, setBalance] = useState("");
  const [note, setNote] = useState("");
  const qc = useQueryClient();

  const { data: subs = [] } = useQuery({
    queryKey: ["subs-month", n],
    queryFn: async () => {
      const { data } = await supabase.from("task_submissions").select("*").like("task_key", `m${n}-%`);
      return data ?? [];
    },
  });

  if (me && me.role !== "admin") return <p className="text-muted-foreground">The roadmap journal is private to the founder.</p>;

  async function lock() {
    if (!ticking || !me) return;
    const { error } = await supabase.from("task_completions").insert({
      task_key: ticking.key,
      completed_by: me.id,
      actual_balance: balance ? Number(balance) : null,
      note: note.trim().slice(0, 500) || null,
    });
    if (error) toast.error(error.code === "23505" ? "Already locked" : error.message);
    else toast.success("Task locked");
    setTicking(null);
    setBalance("");
    setNote("");
    qc.invalidateQueries({ queryKey: ["completions"] });
  }

  const defaultOpen = cur?.month === n ? [`d${cur.day}`] : [];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between text-sm">
        <Link to="/journal" className="text-muted-foreground hover:text-foreground">← All months</Link>
        <div className="flex gap-2">
          {n > 1 && <Button asChild size="sm" variant="ghost"><Link to="/journal/$month" params={{ month: String(n - 1) }}><ChevronLeft className="size-4" />M{n - 1}</Link></Button>}
          {n < 13 && <Button asChild size="sm" variant="ghost"><Link to="/journal/$month" params={{ month: String(n + 1) }}>M{n + 1}<ChevronRight className="size-4" /></Link></Button>}
        </div>
      </div>
      <PageHeader eyebrow={`Month ${String(n).padStart(2, "0")} of 13`} title={m.title.split("—")[1]?.trim() ?? m.title} />

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-5 lg:col-span-2">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-gold">Overview</h2>
          <p className="mt-2 text-sm leading-relaxed">{m.overview}</p>
          <h3 className="mt-5 text-sm font-semibold uppercase tracking-wider text-gold">Management rules</h3>
          <ul className="mt-2 space-y-1.5 text-sm">
            {m.rules.map((r) => <li key={r} className="flex gap-2"><span className="text-gold">▸</span>{r}</li>)}
          </ul>
        </div>
        <div className="space-y-4">
          <div className="panel p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-gold">Accounts</h2>
            <div className="mt-3 space-y-3">
              {m.accounts.map((a) => (
                <div key={a.account} className="text-sm">
                  <div className="flex justify-between"><b>{ACCOUNTS[a.account].name}</b><span className="text-xs text-muted-foreground">{a.owner}</span></div>
                  <div className="text-xs text-muted-foreground">{a.plan}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="panel p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-gold">Expected results</h2>
            <ul className="mt-2 space-y-1 text-sm">{m.results.map((r) => <li key={r}>• {r}</li>)}</ul>
            <div className="num mt-3 border-t border-border pt-3 text-lg text-gold">≈ ${m.cumulative.toLocaleString()} total</div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Day by day</h2>
        <Accordion type="multiple" defaultValue={defaultOpen} className="space-y-2">
          {m.days.map((d) => {
            const active = d.tasks.filter((t) => !t.rest);
            const done = active.filter((t) => comps[t.key]).length;
            const isToday = cur?.month === n && cur.day === d.day;
            return (
              <AccordionItem key={d.day} value={`d${d.day}`} className={`panel border px-4 ${isToday ? "border-gold/60" : ""}`}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex flex-1 items-center gap-3 text-left">
                    <span className="num w-14 text-xs text-muted-foreground">Day {String(d.day).padStart(2, "0")}</span>
                    <span className="flex-1 truncate text-sm font-medium">
                      {active.length === 0 ? <span className="text-muted-foreground"><Coffee className="mr-1 inline size-4" />Rest day{d.weekend ? " · weekend" : ""}</span> : active.map((t) => ACCOUNTS[t.account].short).join(" · ")}
                    </span>
                    {isToday && <span className="rounded bg-gold px-2 py-0.5 text-[10px] font-bold text-primary-foreground">TODAY</span>}
                    {active.length > 0 && <span className={`num mr-2 text-xs ${done === active.length ? "text-success" : "text-muted-foreground"}`}>{done}/{active.length}</span>}
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-3 pb-2">
                    {d.tasks.map((t) => {
                      const c = comps[t.key];
                      const sub = subs.find((s) => s.task_key === t.key);
                      return (
                        <div key={t.key} className={`rounded-xl border p-4 ${c ? "border-success/40 bg-success/5" : "border-border bg-surface"}`}>
                          <div className="flex items-start gap-3">
                            {t.rest ? <Coffee className="mt-0.5 size-5 text-muted-foreground" /> : c ? <CheckCircle2 className="mt-0.5 size-5 text-success" /> : (
                              <button onClick={() => setTicking(t)} aria-label="Tick and lock task"><Circle className="mt-0.5 size-5 text-muted-foreground hover:text-gold" /></button>
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="rounded bg-gold-soft px-2 py-0.5 text-[11px] font-semibold text-gold">{ACCOUNTS[t.account].name}</span>
                                <span className="text-xs text-muted-foreground">Handled by {t.owner}</span>
                              </div>
                              <div className="mt-1.5 font-semibold">{t.title}</div>
                              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">{t.details.map((x) => <li key={x}>• {x}</li>)}</ul>
                              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                                {t.risk && <span className="num rounded bg-secondary px-2 py-1">Risk {t.risk}</span>}
                                {t.target && <span className="num rounded bg-secondary px-2 py-1">Target {t.target}</span>}
                                {t.withdrawal != null && <span className="num rounded bg-gold-soft px-2 py-1 text-gold">Withdraw ${t.withdrawal}</span>}
                              </div>
                              {sub && !c && <div className="mt-3 text-xs text-gold">Team submission: ${String(sub.balance)} · {sub.status} — review in Admin panel</div>}
                              {c && (
                                <div className="mt-3 flex items-center gap-2 text-xs text-success">
                                  <Lock className="size-3" />Locked {format(new Date(c.completed_at), "d MMM yyyy, HH:mm")}
                                  {c.actual_balance != null && ` · balance $${c.actual_balance}`}
                                  {c.note && ` · ${c.note}`}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {d.tasks.length === 0 && <p className="text-sm text-muted-foreground">Nothing scheduled.</p>}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </section>

      <AlertDialog open={!!ticking} onOpenChange={(o) => !o && setTicking(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Lock this task?</AlertDialogTitle>
            <AlertDialogDescription>
              {ticking && `${ACCOUNTS[ticking.account].name} — ${ticking.title}.`} Once ticked it cannot be unticked.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5"><Label htmlFor="bal">Actual balance (optional)</Label><Input id="bal" type="number" value={balance} onChange={(e) => setBalance(e.target.value)} /></div>
            <div className="space-y-1.5"><Label htmlFor="note">Note (optional)</Label><Input id="note" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} /></div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={lock}><Lock className="size-4" />Tick & lock</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
