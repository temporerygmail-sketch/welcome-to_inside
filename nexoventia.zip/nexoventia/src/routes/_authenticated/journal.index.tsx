import { createFileRoute, Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { SectionCounter } from "@/components/SectionCounter";
import { ROADMAP, ACCOUNTS, dayFromStart } from "@/lib/roadmap";
import { useCompletions } from "@/hooks/use-completions";
import { useMe, useSettings } from "@/hooks/use-me";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_authenticated/journal/")({
  head: () => ({ meta: [{ title: "Roadmap journal — Nexoventia" }, { name: "description", content: "The full 13-month Roadmap 2K27." }] }),
  component: JournalIndex,
});

function JournalIndex() {
  const { data: me } = useMe();
  const { data: comps = {} } = useCompletions();
  const { data: settings } = useSettings();
  const cur = settings ? dayFromStart(settings.roadmap_start) : null;
  if (me && me.role !== "admin") return <p className="text-muted-foreground">The roadmap journal is private to the founder.</p>;
  return (
    <div>
      <SectionCounter ids={ROADMAP.map((m) => `month-${m.n}`)} />
      <PageHeader eyebrow="Roadmap 2K27" title="13-month journal" />
      <div className="grid gap-4 md:grid-cols-2">
        {ROADMAP.map((m) => {
          const keys = m.days.flatMap((d) => d.tasks.filter((t) => !t.rest).map((t) => t.key));
          const done = keys.filter((k) => comps[k]).length;
          const pct = keys.length ? Math.round((done / keys.length) * 100) : 0;
          const current = cur?.month === m.n;
          return (
            <Link
              key={m.n}
              id={`month-${m.n}`}
              to="/journal/$month"
              params={{ month: String(m.n) }}
              className={`panel group block p-5 transition-colors hover:border-gold/50 ${current ? "border-gold/60 shadow-gold" : ""}`}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="num text-[11px] uppercase tracking-[0.25em] text-gold">Month {String(m.n).padStart(2, "0")}{current && " · current"}</div>
                  <h2 className="mt-1 text-lg font-semibold">{m.title.split("—")[1]?.trim()}</h2>
                </div>
                <div className="num text-right">
                  <div className="text-xs text-muted-foreground">Target total</div>
                  <div className="text-gold">${m.cumulative.toLocaleString()}</div>
                </div>
              </div>
              <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{m.overview}</p>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {m.accounts.map((a) => <span key={a.account} className="rounded bg-secondary px-2 py-0.5 text-[11px]">{ACCOUNTS[a.account].short} · {a.owner}</span>)}
              </div>
              <div className="mt-4 flex items-center gap-3">
                <Progress value={pct} className="h-1.5" />
                <span className="num flex items-center gap-1 text-xs text-muted-foreground"><Lock className="size-3" />{done}/{keys.length}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
