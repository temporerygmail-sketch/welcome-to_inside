import { createFileRoute, notFound } from "@tanstack/react-router";
import { channelBySlug } from "@/lib/channels";
import { useMe } from "@/hooks/use-me";
import { ChatRoom } from "@/components/ChatRoom";
import { PageHeader } from "@/components/PageHeader";

export const Route = createFileRoute("/_authenticated/channel/$slug")({
  loader: ({ params }) => {
    const c = channelBySlug(params.slug);
    if (!c) throw notFound();
    return c;
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.name ?? "Channel"} — Nexoventia` }, { name: "description", content: loaderData?.description ?? "Nexoventia channel" }] }),
  component: ChannelPage,
});

function ChannelPage() {
  const c = Route.useLoaderData();
  const { data: me } = useMe();
  if (!me) return null;
  if (!c.readers.includes(me.role)) return <p className="text-muted-foreground">This channel is for team members only.</p>;
  return (
    <div>
      <PageHeader eyebrow={c.group} title={c.name}><p className="text-sm text-muted-foreground">{c.description}</p></PageHeader>
      <ChatRoom key={c.slug} source={{ kind: "channel", channel: c.slug }} canPost={c.posters.includes(me.role)} />
    </div>
  );
}
