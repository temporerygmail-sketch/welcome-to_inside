import { createFileRoute, Link, Outlet, redirect, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { BarChart3, BookOpen, ClipboardCheck, Hash, LayoutDashboard, LogOut, Mail, Menu, Shield, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { InstallButton } from "@/components/InstallButton";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useMe } from "@/hooks/use-me";
import { CHANNELS } from "@/lib/channels";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: Shell,
});

function Nav({ onNav }: { onNav?: () => void }) {
  const { data: me } = useMe();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const role = me?.role ?? "member";
  const item = (to: string, label: string, Icon: typeof Hash, params?: Record<string, string>) => {
    const href = params ? to.replace("$slug", params["slug"] ?? "") : to;
    const active = path === href;
    return (
      <Link
        key={href}
        to={to}
        params={params as never}
        onClick={onNav}
        className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${active ? "bg-sidebar-accent text-gold" : "text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground"}`}
      >
        <Icon className="size-4" /> {label}
      </Link>
    );
  };
  const groups = ["Broadcast", "Community", "Team"] as const;
  return (
    <nav className="flex flex-col gap-6">
      <div className="space-y-1">
        {item("/dashboard", "Dashboard", LayoutDashboard)}
        {item("/signals", "Signal stats", BarChart3)}
        {role === "team" && item("/tasks", "My tasks", ClipboardCheck)}
        {role === "admin" && item("/journal", "Roadmap journal", BookOpen)}
        {item("/messages", role === "admin" ? "Inbox" : "Message founder", Mail)}
        {role === "admin" && item("/admin", "Admin panel", Shield)}
      </div>
      {groups.map((g) => {
        const list = CHANNELS.filter((c) => c.group === g && c.readers.includes(role));
        if (!list.length) return null;
        return (
          <div key={g}>
            <div className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">{g}</div>
            <div className="space-y-1">{list.map((c) => item("/channel/$slug", c.name, Hash, { slug: c.slug }))}</div>
          </div>
        );
      })}
    </nav>
  );
}

function Shell() {
  const { data: me } = useMe();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (me?.profile?.blocked) {
    return (
      <div className="flex min-h-screen items-center justify-center p-6 text-center">
        <div className="panel max-w-sm p-8">
          <Logo />
          <h1 className="mt-6 text-xl font-bold">Account blocked</h1>
          <p className="mt-2 text-sm text-muted-foreground">Your access has been blocked by the admin.</p>
          <Button className="mt-6" variant="outline" onClick={signOut}>Sign out</Button>
        </div>
      </div>
    );
  }

  const footer = (
    <div className="space-y-2 border-t border-sidebar-border pt-4">
      <Link to="/profile" onClick={() => setOpen(false)} className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm hover:bg-sidebar-accent">
        <UserRound className="size-4" />
        <div className="min-w-0">
          <div className="truncate font-medium">{me?.profile?.username ?? me?.email}</div>
          <div className="text-[10px] uppercase tracking-wider text-gold">{me?.role === "admin" ? "Founder" : me?.role === "team" ? "Team" : "Member"}</div>
        </div>
      </Link>
      <button onClick={signOut} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-sidebar-accent">
        <LogOut className="size-4" /> Sign out
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col justify-between border-r border-sidebar-border bg-sidebar p-4 lg:flex">
        <div className="flex min-h-0 flex-col gap-6">
          <Link to="/dashboard" className="px-2 pt-1"><Logo /></Link>
          <div className="min-h-0 overflow-y-auto"><Nav /></div>
        </div>
        {footer}
      </aside>

      <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-border bg-background/80 px-4 backdrop-blur-xl lg:hidden">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild><Button size="icon" variant="ghost" aria-label="Open menu"><Menu /></Button></SheetTrigger>
          <SheetContent side="left" className="flex w-72 flex-col justify-between bg-sidebar p-4">
            <div className="flex min-h-0 flex-col gap-6">
              <Logo />
              <div className="min-h-0 overflow-y-auto"><Nav onNav={() => setOpen(false)} /></div>
            </div>
            {footer}
          </SheetContent>
        </Sheet>
        <Logo size={28} />
        <InstallButton variant="ghost" />
      </header>

      <main className="lg:pl-64">
        <div className="hidden justify-end px-8 pt-5 lg:flex"><InstallButton variant="ghost" /></div>
        <div className="mx-auto max-w-6xl px-4 pb-16 pt-4 lg:px-8"><Outlet /></div>
      </main>
    </div>
  );
}
