import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ArrowRight, CalendarDays, ClipboardCheck, Megaphone, Radio, Users } from "lucide-react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useSettings } from "@/hooks/use-me";
import { PageHeader } from "@/components/PageHeader";
import { SignalRow, SignalStats, useSignals } from "@/components/SignalStats";
import { ACCOUNTS, ROADMAP, dayFromStart, tasksForAccount, type AccountId } from "@/lib/roadmap";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Nexoventia" }, { name: "description", content: "Your Nexoventia dashboard." }] }),
  component: Dashboard,
});

function Dashboard() {
  const { data: me } = useMe();
  const { data: settings } = useSettings();
  const cur = settings ? dayFromStart(settings.roadmap_start) : null;
  const name = me?.profile?.first_name ?? me?.profile?.username ?? "";

  return (
    <div className="space-y-8">
      <PageHeader eyebrow={format(new Date(), "EEEE, d MMMM yyyy")} title={`Welcome${name ? `, ${name}` : ""}`}>
        {cur && (me?.role === "admin" || me?.role === "team") && (
          <div className="flex items-center gap-3 rounded-xl border border-gold/30 bg-gold-soft px-4 py-2">
            <CalendarDays className="size-5 text-gold" />
            <div className="num text-sm">Month <b>{cur.month}</b> · Day <b>{cur.day}</b> <span className="text-muted-foreground">({cur.absolute}/390)</span></div>
          </div>
        )}
      </PageHeader>

      {me?.role === "team" && cur && <TeamToday month={cur.month} day={cur.day} account={me.profile?.assigned_account as AccountId | null} shared={!!settings?.share_tasks} />}
      {me?.role === "admin" && cur && <AdminOverview month={cur.month} day={cur.day} />}

      <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <LatestUpdates />
        <ActiveSignals />
      </div>
      <SignalStats />
    </div>
  );
}

function TeamToday({ month, day, account, shared }: { month: number; day: number; account: AccountId | null; shared: boolean }) {
  const tasks = tasksForAccount(month, day, account);
  return (
    <section className="panel overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-surface px-5 py-4">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Your account</div>
          <div className="font-display text-lg font-semibold">{account ? ACCOUNTS[account].name : "No account assigned"}</div>
        </div>
        <Button asChild size="sm"><Link to="/tasks"><ClipboardCheck className="size-4" />Open my tasks</Link></Button>
      </div>
      <div className="p-5">
        {!shared ? (
          <p className="text-sm text-muted-foreground">The founder hasn't shared today's tasks yet.</p>
        ) : tasks.length === 0 ? (
          <p className="text-sm text-muted-foreground">No task for your account today.</p>
        ) : (
          tasks.map((t) => (
            <div key={t.key}>
              <div className="font-semibold">{t.title}</div>
              <div className="mt-2 flex flex-wrap gap-2 text-xs">
                {t.risk && <span className="num rounded bg-secondary px-2 py-1">Risk {t.risk}</span>}
                {t.target && <span className="num rounded bg-secondary px-2 py-1">Target {t.target}</span>}
                {t.withdrawal != null && <span className="num rounded bg-gold-soft px-2 py-1 text-gold">Withdraw ${t.withdrawal}</span>}
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

function AdminOverview({ month, day }: { month: number; day: number }) {
  const { data } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: async () => {
      const [roles, subs, comps] = await Promise.all([
        supabase.from("user_roles").select("role"),
        supabase.from("task_submissions").select("id", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("task_completions").select("task_key"),
      ]);
      const r = roles.data ?? [];
      return {
        members: r.filter((x) => x.role === "member").length,
        team: r.filter((x) => x.role === "team").length,
        pending: subs.count ?? 0,
        completed: new Set((comps.data ?? []).map((c) => c.task_key)),
      };
    },
  });
  const chart = ROADMAP.map((m) => {
    const keys = m.days.flatMap((d) => d.tasks.filter((t) => !t.rest).map((t) => t.key));
    return { month: `M${m.n}`, planned: m.cumulative, done: keys.length ? Math.round((keys.filter((k) => data?.completed.has(k)).length / keys.length) * 100) : 0 };
  });
  const today = tasksForAccount(month, day);
  return (
    <section className="space-y-6">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          [Users, "Public members", data?.members ?? "–"],
          [Users, "Team members", data?.team ?? "–"],
          [ClipboardCheck, "Pending reviews", data?.pending ?? "–"],
          [CalendarDays, "Tasks today", today.length],
        ].map(([I, l, v]) => {
          const Icon = I as typeof Users;
          return (
            <div key={l as string} className="panel p-4">
              <Icon className="size-4 text-gold" />
              <div className="num mt-3 text-2xl font-semibold">{v as number}</div>
              <div className="text-xs text-muted-foreground">{l as string}</div>
            </div>
          );
        })}
      </div>
      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="panel p-4">
          <div className="mb-2 text-sm font-semibold">Planned capital by month (USD)</div>
          <div className="h-60">
            <ResponsiveContainer>
              <AreaChart data={chart}>
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--gold)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--gold)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Area dataKey="planned" stroke="var(--gold)" fill="url(#g)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="panel p-4">
          <div className="mb-3 flex items-center justify-between text-sm font-semibold">Today in the journal <Link to="/journal/$month" params={{ month: String(month) }} className="text-xs text-gold">Open →</Link></div>
          <div className="space-y-2">
            {today.map((t) => (
              <div key={t.key} className="flex items-center justify-between rounded-lg bg-surface px-3 py-2 text-sm">
                <span className="truncate"><b className="text-gold">{ACCOUNTS[t.account].short}</b> · {t.title}</span>
                {data?.completed.has(t.key) && <span className="text-xs text-success">Locked</span>}
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-13 gap-1">
            {chart.map((c) => (
              <div key={c.month} title={`${c.month}: ${c.done}%`} className="h-10 rounded bg-secondary">
                <div className="w-full rounded bg-gold" style={{ height: `${c.done}%` }} />
              </div>
            ))}
          </div>
          <div className="mt-1 text-[10px] text-muted-foreground">Completion per month</div>
        </div>
      </div>
    </section>
  );
}

function LatestUpdates() {
  const { data = [] } = useQuery({
    queryKey: ["latest-updates"],
    queryFn: async () => {
      const { data } = await supabase.from("messages").select("*").eq("channel", "updates").order("created_at", { ascending: false }).limit(5);
      return data ?? [];
    },
  });
  return (
    <section className="panel p-5">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-semibold"><Megaphone className="size-4 text-gold" />Latest updates & news</h2>
        <Link to="/channel/$slug" params={{ slug: "updates" }} className="text-xs text-gold">All <ArrowRight className="inline size-3" /></Link>
      </div>
      {data.length === 0 ? <p className="text-sm text-muted-foreground">No updates yet.</p> : (
        <div className="space-y-4">
          {data.map((m) => (
            <div key={m.id} className="border-l-2 border-gold/50 pl-3">
              <div className="num text-[11px] text-muted-foreground">{format(new Date(m.created_at), "d MMM, HH:mm")}</div>
              <p className="mt-0.5 line-clamp-3 whitespace-pre-wrap text-sm">{m.body ?? "📎 Attachment"}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function ActiveSignals() {
  const { data = [] } = useSignals();
  const active = data.filter((s) => s.status === "active").slice(0, 6);
  return (
    <section className="panel p-5">
      <h2 className="mb-2 flex items-center gap-2 font-semibold"><Radio className="size-4 text-gold" />Active signals</h2>
      {active.length === 0 ? <p className="text-sm text-muted-foreground">No active signals right now.</p> : active.map((s) => <SignalRow key={s.id} s={s} />)}
    </section>
  );
}
