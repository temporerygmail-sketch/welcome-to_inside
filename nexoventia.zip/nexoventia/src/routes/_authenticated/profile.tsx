import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Camera } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useMe } from "@/hooks/use-me";
import { uploadMedia, useMediaUrl } from "@/lib/media";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ACCOUNTS, type AccountId } from "@/lib/roadmap";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profile — Nexoventia" }, { name: "description", content: "Your Nexoventia profile." }] }),
  component: Profile,
});

function Profile() {
  const { data: me } = useMe();
  const qc = useQueryClient();
  const [f, setF] = useState<{ first_name?: string; last_name?: string; phone?: string }>({});
  const { data: avatar } = useMediaUrl(me?.profile?.avatar_url);

  useEffect(() => {
    if (me?.profile) setF({ first_name: me.profile.first_name ?? "", last_name: me.profile.last_name ?? "", phone: me.profile.phone ?? "" });
  }, [me?.profile]);
  if (!me) return null;

  async function save() {
    const { error } = await supabase.from("profiles").update({ first_name: (f.first_name ?? "").trim(), last_name: (f.last_name ?? "").trim(), phone: (f.phone ?? "").trim() }).eq("id", me!.id);
    if (error) return void toast.error(error.message);
    toast.success("Profile saved");
    qc.invalidateQueries({ queryKey: ["me"] });
  }
  async function photo(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return void toast.error("Choose an image");
    const path = await uploadMedia(me!.id, file, file.name);
    await supabase.from("profiles").update({ avatar_url: path }).eq("id", me!.id);
    qc.invalidateQueries({ queryKey: ["me"] });
    toast.success("Photo updated");
  }

  return (
    <div className="max-w-xl">
      <PageHeader eyebrow={me.role === "admin" ? "Founder" : me.role === "team" ? "Team member" : "Member"} title="Your profile" />
      <div className="panel space-y-5 p-6">
        <label className="flex cursor-pointer items-center gap-4">
          {avatar ? <img src={avatar} alt="Profile" className="size-20 rounded-full object-cover" /> : <div className="flex size-20 items-center justify-center rounded-full bg-secondary"><Camera className="text-muted-foreground" /></div>}
          <span className="text-sm text-gold">Change profile photo</span>
          <input type="file" accept="image/*" className="hidden" onChange={(e) => photo(e.target.files?.[0])} />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5"><Label>First name</Label><Input value={f.first_name ?? ""} onChange={(e) => setF({ ...f, first_name: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Last name</Label><Input value={f.last_name ?? ""} onChange={(e) => setF({ ...f, last_name: e.target.value })} /></div>
        </div>
        <div className="space-y-1.5"><Label>Phone</Label><Input value={f.phone ?? ""} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div><div className="text-xs text-muted-foreground">Email</div>{me.email}</div>
          <div><div className="text-xs text-muted-foreground">Username</div>@{me.profile?.username}</div>
          {me.role === "team" && <div><div className="text-xs text-muted-foreground">Account</div>{me.profile?.assigned_account ? ACCOUNTS[me.profile.assigned_account as AccountId]?.name : "—"}</div>}
        </div>
        <Button onClick={save}>Save changes</Button>
      </div>
    </div>
  );
}
