import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, Clock, Lock, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useSettings } from "@/hooks/use-me";
import { useCompletions } from "@/hooks/use-completions";
import { PageHeader } from "@/components/PageHeader";
import { ACCOUNTS, dayFromStart, tasksForAccount, DAYS_PER_MONTH, TOTAL_DAYS, type AccountId, type Task } from "@/lib/roadmap";
import { uploadMedia } from "@/lib/media";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/tasks")({
  head: () => ({ meta: [{ title: "My tasks — Nexoventia" }, { name: "description", content: "Today's account tasks." }] }),
  component: TasksPage,
});

function TasksPage() {
  const { data: me } = useMe();
  const { data: settings } = useSettings();
  if (!me || !settings) return null;
  if (me.role !== "team" && me.role !== "admin") return <p className="text-muted-foreground">Tasks are for team members.</p>;
  const account = me.profile?.assigned_account as AccountId | null;
  const cur = dayFromStart(settings.roadmap_start);
  const upcoming = Array.from({ length: 6 }, (_, i) => cur.absolute + i).filter((a) => a <= TOTAL_DAYS).map((a) => ({ month: Math.floor((a - 1) / DAYS_PER_MONTH) + 1, day: ((a - 1) % DAYS_PER_MONTH) + 1 }));

  return (
    <div className="space-y-6">
      <PageHeader eyebrow={`Month ${cur.month} · Day ${cur.day}`} title="My tasks">
        <div className="rounded-lg bg-secondary px-3 py-1.5 text-sm">{account ? ACCOUNTS[account].name : "No account assigned"}</div>
      </PageHeader>
      {!settings.share_tasks ? (
        <div className="panel p-8 text-center text-muted-foreground"><Clock className="mx-auto mb-3 size-8" />The founder hasn't shared today's tasks yet. Check back soon.</div>
      ) : (
        <>
          {tasksForAccount(cur.month, cur.day, account).map((t) => <TaskCard key={t.key} t={t} />)}
          {tasksForAccount(cur.month, cur.day, account).length === 0 && <div className="panel p-6 text-sm text-muted-foreground">No task for your account today.</div>}
          <section className="panel p-5">
            <h2 className="mb-3 font-semibold">Upcoming schedule</h2>
            <div className="space-y-2">
              {upcoming.slice(1).map((u) => {
                const ts = tasksForAccount(u.month, u.day, account);
                return (
                  <div key={`${u.month}-${u.day}`} className="flex items-center gap-3 rounded-lg bg-surface px-3 py-2 text-sm">
                    <span className="num w-20 text-xs text-muted-foreground">M{u.month} D{u.day}</span>
                    <span className="flex-1 truncate">{ts.map((t) => t.title).join(" · ") || "—"}</span>
                  </div>
                );
              })}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function TaskCard({ t }: { t: Task }) {
  const { data: me } = useMe();
  const { data: comps = {} } = useCompletions();
  const qc = useQueryClient();
  const [balance, setBalance] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const { data: sub } = useQuery({
    queryKey: ["my-sub", t.key],
    queryFn: async () => (await supabase.from("task_submissions").select("*").eq("task_key", t.key).eq("user_id", me!.id).maybeSingle()).data,
    enabled: !!me,
  });
  const locked = comps[t.key];

  async function submit() {
    if (!me) return;
    if (!balance) return void toast.error("Enter your current balance");
    if (!file) return void toast.error("Attach a screenshot of your balance");
    setBusy(true);
    try {
      const path = await uploadMedia(me.id, file, file.name);
      const { error } = await supabase.from("task_submissions").insert({ user_id: me.id, task_key: t.key, account: t.account, balance: Number(balance), screenshot_url: path, note: note.trim().slice(0, 500) || null });
      if (error) throw error;
      toast.success("Submitted and locked — sent to the founder");
      qc.invalidateQueries({ queryKey: ["my-sub", t.key] });
    } catch (e) {
      toast.error((e as Error).message);
    }
    setBusy(false);
  }

  return (
    <div className="panel overflow-hidden">
      <div className="border-b border-border bg-surface px-5 py-3 text-xs uppercase tracking-wider text-gold">Today · {ACCOUNTS[t.account].name}</div>
      <div className="p-5">
        <h2 className="text-lg font-semibold">{t.title}</h2>
        <ul className="mt-2 space-y-1 text-sm text-muted-foreground">{t.details.map((x) => <li key={x}>• {x}</li>)}</ul>
        <div className="mt-3 flex flex-wrap gap-2 text-xs">
          {t.risk && <span className="num rounded bg-secondary px-2 py-1">Risk {t.risk}</span>}
          {t.target && <span className="num rounded bg-secondary px-2 py-1">Target {t.target}</span>}
          {t.withdrawal != null && <span className="num rounded bg-gold-soft px-2 py-1 text-gold">Withdraw ${t.withdrawal}</span>}
        </div>
        {t.rest ? null : locked ? (
          <div className="mt-5 flex items-center gap-2 text-sm text-success"><CheckCircle2 className="size-4" />Approved and locked by the founder.</div>
        ) : sub ? (
          <div className="mt-5 flex items-center gap-2 text-sm text-gold"><Lock className="size-4" />Submitted (balance ${String(sub.balance)}) — status: {sub.status}.</div>
        ) : (
          <div className="mt-5 grid gap-3 rounded-xl border border-dashed border-border p-4 sm:grid-cols-2">
            <div className="space-y-1.5"><Label htmlFor={`b-${t.key}`}>Current balance (USD)</Label><Input id={`b-${t.key}`} type="number" value={balance} onChange={(e) => setBalance(e.target.value)} /></div>
            <div className="space-y-1.5"><Label htmlFor={`f-${t.key}`}>Balance screenshot</Label><Input id={`f-${t.key}`} type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></div>
            <div className="space-y-1.5 sm:col-span-2"><Label htmlFor={`n-${t.key}`}>Today's details</Label><Input id={`n-${t.key}`} value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="Trades taken, result, notes" /></div>
            <Button className="sm:col-span-2" onClick={submit} disabled={busy}><Upload className="size-4" />Tick, lock & send</Button>
          </div>
        )}
      </div>
    </div>
  );
}
