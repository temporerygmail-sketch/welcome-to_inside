import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Ban, Check, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useSettings } from "@/hooks/use-me";
import { PageHeader } from "@/components/PageHeader";
import { SignalRow, useSignals, type Signal } from "@/components/SignalStats";
import { ACCOUNTS } from "@/lib/roadmap";
import { removeUser } from "@/lib/admin.functions";
import { useMediaUrl } from "@/lib/media";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin panel — Nexoventia" }, { name: "description", content: "Founder control panel." }] }),
  component: Admin,
});

function Admin() {
  const { data: me } = useMe();
  if (!me) return null;
  if (me.role !== "admin") return <p className="text-muted-foreground">Not available.</p>;
  return (
    <div>
      <PageHeader eyebrow="Founder" title="Admin panel" />
      <Tabs defaultValue="submissions">
        <TabsList className="flex h-auto flex-wrap justify-start">
          <TabsTrigger value="submissions">Team submissions</TabsTrigger>
          <TabsTrigger value="team">Team members</TabsTrigger>
          <TabsTrigger value="members">Public members</TabsTrigger>
          <TabsTrigger value="signals">Signals</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="submissions"><Submissions /></TabsContent>
        <TabsContent value="team"><People role="team" /></TabsContent>
        <TabsContent value="members"><People role="member" /></TabsContent>
        <TabsContent value="signals"><Signals /></TabsContent>
        <TabsContent value="settings"><Settings /></TabsContent>
      </Tabs>
    </div>
  );
}

function People({ role }: { role: "team" | "member" }) {
  const qc = useQueryClient();
  const remove = useServerFn(removeUser);
  const [q, setQ] = useState("");
  const { data = [] } = useQuery({
    queryKey: ["people", role],
    queryFn: async () => {
      const { data: r } = await supabase.from("user_roles").select("user_id").eq("role", role);
      const ids = (r ?? []).map((x) => x.user_id);
      if (!ids.length) return [];
      const { data } = await supabase.from("profiles").select("*").in("id", ids).order("created_at", { ascending: false });
      return data ?? [];
    },
  });
  const list = data.filter((p) => JSON.stringify(p).toLowerCase().includes(q.toLowerCase()));

  async function toggleBlock(id: string, blocked: boolean) {
    const { error } = await supabase.from("profiles").update({ blocked: !blocked }).eq("id", id);
    if (error) return void toast.error(error.message);
    toast.success(blocked ? "Unblocked" : "Blocked");
    qc.invalidateQueries({ queryKey: ["people", role] });
  }
  async function setAccount(id: string, acc: string) {
    const { error } = await supabase.from("profiles").update({ assigned_account: acc }).eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["people", role] });
  }
  async function del(id: string) {
    if (!confirm("Permanently remove this user?")) return;
    try {
      await remove({ data: { userId: id } });
      toast.success("User removed");
      qc.invalidateQueries({ queryKey: ["people", role] });
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="panel mt-4 overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b border-border p-4">
        <span className="text-sm text-muted-foreground">{data.length} {role === "team" ? "team members" : "public members"}</span>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" className="max-w-xs" />
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead><TableHead>Contact</TableHead><TableHead>Age</TableHead><TableHead>Deposit</TableHead>
              {role === "team" && <TableHead>Account</TableHead>}
              <TableHead>Joined</TableHead><TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {list.map((p) => (
              <TableRow key={p.id} className={p.blocked ? "opacity-50" : ""}>
                <TableCell><div className="font-medium">{p.first_name} {p.last_name}</div><div className="text-xs text-muted-foreground">@{p.username}</div></TableCell>
                <TableCell className="text-xs"><div>{p.email}</div><div className="text-muted-foreground">{p.phone}</div></TableCell>
                <TableCell className="num">{p.age}</TableCell>
                <TableCell className="num text-xs">${p.deposit_min ?? 0} – ${p.deposit_max ?? 0}</TableCell>
                {role === "team" && (
                  <TableCell>
                    <Select value={p.assigned_account ?? ""} onValueChange={(v) => setAccount(p.id, v)}>
                      <SelectTrigger className="h-8 w-36"><SelectValue placeholder="None" /></SelectTrigger>
                      <SelectContent>{Object.entries(ACCOUNTS).map(([k, a]) => <SelectItem key={k} value={k}>{a.short}</SelectItem>)}</SelectContent>
                    </Select>
                  </TableCell>
                )}
                <TableCell className="text-xs">{format(new Date(p.created_at), "d MMM yyyy")}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button size="sm" variant="ghost" onClick={() => toggleBlock(p.id, p.blocked)}><Ban className="size-4" />{p.blocked ? "Unblock" : "Block"}</Button>
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => del(p.id)} aria-label="Remove"><Trash2 className="size-4" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {list.length === 0 && <TableRow><TableCell colSpan={7} className="py-10 text-center text-muted-foreground">No users yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function Shot({ path }: { path: string | null }) {
  const { data } = useMediaUrl(path);
  if (!data) return null;
  return <a href={data} target="_blank" rel="noreferrer"><img src={data} alt="Balance screenshot" className="h-20 w-32 rounded-lg object-cover" /></a>;
}

function Submissions() {
  const qc = useQueryClient();
  const { data: me } = useMe();
  const { data = [] } = useQuery({
    queryKey: ["submissions"],
    queryFn: async () => {
      const { data } = await supabase.from("task_submissions").select("*").order("created_at", { ascending: false }).limit(200);
      const ids = Array.from(new Set((data ?? []).map((s) => s.user_id)));
      const { data: ps } = ids.length ? await supabase.from("profiles").select("id, username, first_name").in("id", ids) : { data: [] };
      const names = Object.fromEntries((ps ?? []).map((p) => [p.id, p.username ?? p.first_name]));
      return (data ?? []).map((s) => ({ ...s, name: names[s.user_id] ?? "Member" }));
    },
  });

  async function review(id: string, key: string, balance: number, approve: boolean) {
    const { error } = await supabase.from("task_submissions").update({ status: approve ? "approved" : "rejected" }).eq("id", id);
    if (error) return void toast.error(error.message);
    if (approve) {
      const { error: e2 } = await supabase.from("task_completions").insert({ task_key: key, completed_by: me!.id, actual_balance: balance, note: "Approved team submission" });
      if (e2 && e2.code !== "23505") toast.error(e2.message);
    }
    toast.success(approve ? "Approved & locked in journal" : "Rejected");
    qc.invalidateQueries({ queryKey: ["submissions"] });
    qc.invalidateQueries({ queryKey: ["completions"] });
  }

  return (
    <div className="mt-4 space-y-3">
      {data.length === 0 && <div className="panel p-8 text-center text-sm text-muted-foreground">No submissions yet.</div>}
      {data.map((s) => (
        <div key={s.id} className="panel flex flex-wrap items-center gap-4 p-4">
          <Shot path={s.screenshot_url} />
          <div className="min-w-0 flex-1">
            <div className="font-semibold">{s.name} · <span className="text-gold">{ACCOUNTS[s.account as keyof typeof ACCOUNTS]?.short ?? s.account}</span></div>
            <div className="num text-xs text-muted-foreground">{s.task_key} · {format(new Date(s.created_at), "d MMM HH:mm")}</div>
            <div className="num mt-1 text-sm">Balance ${String(s.balance)}</div>
            {s.note && <div className="text-sm text-muted-foreground">{s.note}</div>}
          </div>
          {s.status === "pending" ? (
            <div className="flex gap-2">
              <Button size="sm" onClick={() => review(s.id, s.task_key, Number(s.balance), true)}><Check className="size-4" />Approve</Button>
              <Button size="sm" variant="outline" onClick={() => review(s.id, s.task_key, Number(s.balance), false)}><X className="size-4" />Reject</Button>
            </div>
          ) : <span className={`text-sm capitalize ${s.status === "approved" ? "text-success" : "text-destructive"}`}>{s.status}</span>}
        </div>
      ))}
    </div>
  );
}

type SigForm = { market: string; direction: string; pair?: string; entry?: string; take_profit?: string; stop_loss?: string; expiry?: string; note?: string };

function Signals() {
  const qc = useQueryClient();
  const { data = [] } = useSignals();
  const [f, setF] = useState<SigForm>({ market: "forex", direction: "BUY" });
  const set = (k: keyof SigForm, v: string) => setF((x) => ({ ...x, [k]: v }));
  const num = (v?: string) => (v ? Number(v) : null);

  async function create() {
    if (!f.pair?.trim()) return void toast.error("Pair required");
    const { error } = await supabase.from("signals").insert({
      market: f.market, pair: f.pair.trim().toUpperCase(), direction: f.direction, entry: num(f.entry), take_profit: num(f.take_profit), stop_loss: num(f.stop_loss), expiry: f.expiry || null, note: f.note || null,
    });
    if (error) return void toast.error(error.message);
    const text = `${f.market === "quotex" ? "⚡ QUOTEX" : "📈 FOREX"} SIGNAL\n${f.pair.toUpperCase()} — ${f.direction}${f.entry ? `\nEntry: ${f.entry}` : ""}${f.take_profit ? `\nTP: ${f.take_profit}` : ""}${f.stop_loss ? `\nSL: ${f.stop_loss}` : ""}${f.expiry ? `\nExpiry: ${f.expiry}` : ""}${f.note ? `\n${f.note}` : ""}`;
    const { data: u } = await supabase.auth.getUser();
    await supabase.from("messages").insert({ channel: f.market === "quotex" ? "quotex-signals" : "forex-signals", user_id: u.user!.id, body: text });
    toast.success("Signal posted");
    setF({ market: f.market, direction: f.direction });
    qc.invalidateQueries({ queryKey: ["signals"] });
  }

  async function close(s: Signal, status: string) {
    let pips: number | null = null;
    if (s.market === "forex") {
      const p = prompt(`Pips for ${status.toUpperCase()}?`);
      if (p === null) return;
      pips = Math.abs(Number(p) || 0);
    }
    const { error } = await supabase.from("signals").update({ status, pips, closed_at: new Date().toISOString() }).eq("id", s.id);
    if (error) return void toast.error(error.message);
    const { data: u } = await supabase.auth.getUser();
    await supabase.from("messages").insert({ channel: s.market === "quotex" ? "quotex-signals" : "forex-signals", user_id: u.user!.id, body: `${s.pair} ${s.direction} → ${status.toUpperCase()}${pips != null ? ` (${status === "tp" ? "+" : "−"}${pips} pips)` : ""}` });
    qc.invalidateQueries({ queryKey: ["signals"] });
  }

  return (
    <div className="mt-4 grid gap-4 lg:grid-cols-[360px_1fr]">
      <div className="panel space-y-3 p-5">
        <h2 className="font-semibold">New signal</h2>
        <div className="grid grid-cols-2 gap-2">
          <Select value={f.market} onValueChange={(v) => { set("market", v); set("direction", v === "quotex" ? "CALL" : "BUY"); }}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="forex">Forex</SelectItem><SelectItem value="quotex">Quotex</SelectItem></SelectContent>
          </Select>
          <Select value={f.direction} onValueChange={(v) => set("direction", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{(f.market === "quotex" ? ["CALL", "PUT"] : ["BUY", "SELL"]).map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5"><Label>Pair</Label><Input value={f.pair ?? ""} onChange={(e) => set("pair", e.target.value)} placeholder="EUR/USD" /></div>
        {f.market === "forex" ? (
          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1.5"><Label>Entry</Label><Input type="number" value={f.entry ?? ""} onChange={(e) => set("entry", e.target.value)} /></div>
            <div className="space-y-1.5"><Label>TP</Label><Input type="number" value={f.take_profit ?? ""} onChange={(e) => set("take_profit", e.target.value)} /></div>
            <div className="space-y-1.5"><Label>SL</Label><Input type="number" value={f.stop_loss ?? ""} onChange={(e) => set("stop_loss", e.target.value)} /></div>
          </div>
        ) : (
          <div className="space-y-1.5"><Label>Expiry</Label><Input value={f.expiry ?? ""} onChange={(e) => set("expiry", e.target.value)} placeholder="1 min" /></div>
        )}
        <div className="space-y-1.5"><Label>Note</Label><Input value={f.note ?? ""} onChange={(e) => set("note", e.target.value)} /></div>
        <Button className="w-full" onClick={create}>Post signal</Button>
        <p className="text-xs text-muted-foreground">Also posts to the matching signal channel automatically.</p>
      </div>
      <div className="panel p-5">
        <h2 className="mb-2 font-semibold">All signals</h2>
        {data.map((s) => (
          <div key={s.id} className="flex items-center gap-2">
            <div className="flex-1"><SignalRow s={s} /></div>
            {s.status === "active" && (
              <div className="flex gap-1">
                {(s.market === "quotex" ? ["win", "loss"] : ["tp", "sl"]).map((st) => (
                  <Button key={st} size="sm" variant="outline" onClick={() => close(s, st)} className="uppercase">{st}</Button>
                ))}
              </div>
            )}
          </div>
        ))}
        {data.length === 0 && <p className="text-sm text-muted-foreground">No signals yet.</p>}
      </div>
    </div>
  );
}

function Settings() {
  const { data: s } = useSettings();
  const qc = useQueryClient();
  if (!s) return null;
  async function update(patch: { share_tasks?: boolean; roadmap_start?: string }) {
    const { error } = await supabase.from("app_settings").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", 1);
    if (error) return void toast.error(error.message);
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: ["settings"] });
  }
  return (
    <div className="panel mt-4 max-w-xl space-y-6 p-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="font-semibold">Send today's tasks to the team</div>
          <div className="text-sm text-muted-foreground">When on, each team member sees their account's task and can submit their balance screenshot.</div>
        </div>
        <Switch checked={s.share_tasks} onCheckedChange={(v) => update({ share_tasks: v })} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="start">Roadmap Day 1 date</Label>
        <Input id="start" type="date" defaultValue={s.roadmap_start} onBlur={(e) => e.target.value && e.target.value !== s.roadmap_start && update({ roadmap_start: e.target.value })} />
        <p className="text-xs text-muted-foreground">The current month and day are counted from this date.</p>
      </div>
    </div>
  );
}
