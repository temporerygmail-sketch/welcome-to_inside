import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Loader2, MailCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { ACCOUNTS } from "@/lib/roadmap";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ mode: z.enum(["signin", "signup"]).optional() }),
  head: () => ({
    meta: [
      { title: "Sign in — Nexoventia" },
      { name: "description", content: "Sign in or create your Nexoventia account." },
      { property: "og:title", content: "Sign in — Nexoventia" },
      { property: "og:description", content: "Access the Nexoventia trading desk." },
    ],
  }),
  component: AuthPage,
});

const signupSchema = z.object({
  first_name: z.string().trim().min(1, "First name required").max(50),
  last_name: z.string().trim().min(1, "Last name required").max(50),
  username: z.string().trim().min(3, "Username min 3 chars").max(30).regex(/^[a-zA-Z0-9_.]+$/, "Letters, numbers, _ and . only"),
  age: z.coerce.number().int().min(16, "Must be 16+").max(100),
  phone: z.string().trim().min(7, "Phone required").max(20),
  email: z.string().trim().email("Valid email required").max(255),
  password: z.string().min(8, "Password min 8 chars").max(72),
  deposit_min: z.coerce.number().min(0),
  deposit_max: z.coerce.number().min(0),
  team_code: z.string().trim().max(40).optional(),
  assigned_account: z.string().optional(),
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const [tab, setTab] = useState(mode ?? "signin");
  const [busy, setBusy] = useState(false);
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);
  const [otp, setOtp] = useState("");
  const [form, setForm] = useState<Record<string, string>>({ deposit_min: "", deposit_max: "" });
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  async function signIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: String(fd.get("email")).trim(), password: String(fd.get("password")) });
    setBusy(false);
    if (error) return void toast.error(error.message);
    navigate({ to: "/dashboard", replace: true });
  }

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    const parsed = signupSchema.safeParse(form);
    if (!parsed.success) return void toast.error(parsed.error.issues[0]?.message ?? "Invalid form");
    const v = parsed.data;
    if (v.deposit_max < v.deposit_min) return void toast.error("Max deposit must be ≥ min deposit");
    if (v.team_code && !v.assigned_account) return void toast.error("Choose the account you handle");
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email: v.email,
      password: v.password,
      options: {
        emailRedirectTo: window.location.origin + "/auth",
        data: {
          first_name: v.first_name, last_name: v.last_name, username: v.username, age: String(v.age), phone: v.phone,
          deposit_min: String(v.deposit_min), deposit_max: String(v.deposit_max),
          team_code: v.team_code ?? "", assigned_account: v.assigned_account ?? "",
        },
      },
    });
    setBusy(false);
    if (error) return void toast.error(error.message);
    setPendingEmail(v.email);
  }

  async function verify() {
    if (!pendingEmail || otp.length < 6) return;
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ email: pendingEmail, token: otp, type: "signup" });
    setBusy(false);
    if (error) return void toast.error(error.message);
    toast.success("Email verified. Welcome to Nexoventia!");
    navigate({ to: "/dashboard", replace: true });
  }

  async function forgot() {
    const email = (document.getElementById("si-email") as HTMLInputElement)?.value.trim();
    if (!email) return void toast.error("Enter your email first");
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + "/reset-password" });
    if (error) return void toast.error(error.message);
    toast.success("Password reset link sent");
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      <aside className="relative hidden overflow-hidden border-r border-border bg-surface bg-grid p-12 lg:flex lg:flex-col lg:justify-between">
        <Link to="/"><Logo /></Link>
        <div>
          <h2 className="text-4xl font-bold leading-tight">The desk where every day <span className="text-gold-gradient">counts and locks.</span></h2>
          <p className="mt-4 max-w-sm text-muted-foreground">Team members: enter your access code during sign up to unlock your account dashboard.</p>
        </div>
        <p className="text-xs text-muted-foreground">© Nexoventia · Roadmap 2K27</p>
      </aside>

      <main className="flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 inline-block lg:hidden"><Logo /></Link>
          {pendingEmail ? (
            <div className="panel p-8 text-center">
              <MailCheck className="mx-auto size-10 text-gold" />
              <h1 className="mt-4 text-2xl font-bold">Verify your email</h1>
              <p className="mt-2 text-sm text-muted-foreground">We sent a message to <b className="text-foreground">{pendingEmail}</b>. Enter the 6-digit code, or click the link in the email.</p>
              <div className="mt-6 flex justify-center">
                <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                  <InputOTPGroup>
                    {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <Button className="mt-6 w-full" onClick={verify} disabled={busy || otp.length < 6}>
                {busy && <Loader2 className="size-4 animate-spin" />} Verify & continue
              </Button>
              <button className="mt-4 text-xs text-muted-foreground underline" onClick={() => setPendingEmail(null)}>Use a different email</button>
            </div>
          ) : (
            <Tabs value={tab} onValueChange={(v) => setTab(v as "signin" | "signup")}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">Sign in</TabsTrigger>
                <TabsTrigger value="signup">Create account</TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <form onSubmit={signIn} className="panel mt-4 space-y-4 p-6">
                  <h1 className="text-2xl font-bold">Welcome back</h1>
                  <div className="space-y-2"><Label htmlFor="si-email">Email</Label><Input id="si-email" name="email" type="email" required autoComplete="email" /></div>
                  <div className="space-y-2"><Label htmlFor="si-pass">Password</Label><Input id="si-pass" name="password" type="password" required autoComplete="current-password" /></div>
                  <Button type="submit" className="w-full" disabled={busy}>{busy && <Loader2 className="size-4 animate-spin" />} Sign in</Button>
                  <button type="button" onClick={forgot} className="w-full text-center text-xs text-muted-foreground underline">Forgot password?</button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={signUp} className="panel mt-4 space-y-4 p-6">
                  <h1 className="text-2xl font-bold">Create your account</h1>
                  <div className="grid grid-cols-2 gap-3">
                    <F label="First name" k="first_name" form={form} set={set} />
                    <F label="Last name" k="last_name" form={form} set={set} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <F label="Username" k="username" form={form} set={set} />
                    <F label="Age" k="age" type="number" form={form} set={set} />
                  </div>
                  <F label="Phone number" k="phone" type="tel" form={form} set={set} />
                  <F label="Email" k="email" type="email" form={form} set={set} />
                  <F label="Password" k="password" type="password" form={form} set={set} />
                  <div className="grid grid-cols-2 gap-3">
                    <F label="Min deposit (USD)" k="deposit_min" type="number" form={form} set={set} />
                    <F label="Max deposit (USD)" k="deposit_max" type="number" form={form} set={set} />
                  </div>
                  <div className="rounded-lg border border-dashed border-gold/40 bg-gold-soft p-4">
                    <F label="Team access code (optional)" k="team_code" form={form} set={set} placeholder="Only for team members" />
                    {form["team_code"]?.trim() && (
                      <div className="mt-3 space-y-2">
                        <Label>Which account do you handle?</Label>
                        <Select value={form["assigned_account"] ?? ""} onValueChange={(v) => set("assigned_account", v)}>
                          <SelectTrigger><SelectValue placeholder="Choose account" /></SelectTrigger>
                          <SelectContent>
                            {Object.entries(ACCOUNTS).map(([id, a]) => <SelectItem key={id} value={id}>{a.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">You can add your profile photo after signing in.</p>
                  <Button type="submit" className="w-full" disabled={busy}>{busy && <Loader2 className="size-4 animate-spin" />} Create account</Button>
                </form>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
    </div>
  );
}

function F({ label, k, type = "text", form, set, placeholder }: { label: string; k: string; type?: string; form: Record<string, string>; set: (k: string, v: string) => void; placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={k}>{label}</Label>
      <Input id={k} type={type} value={form[k] ?? ""} placeholder={placeholder} onChange={(e) => set(k, e.target.value)} />
    </div>
  );
}
