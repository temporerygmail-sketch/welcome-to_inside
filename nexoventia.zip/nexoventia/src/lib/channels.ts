import type { Role } from "@/hooks/use-me";

export type Channel = {
  slug: string;
  name: string;
  description: string;
  readers: Role[];
  posters: Role[];
  group: "Broadcast" | "Community" | "Team";
};

export const CHANNELS: Channel[] = [
  { slug: "updates", name: "Updates & News", description: "Announcements and market news from the founder.", readers: ["admin", "team", "member"], posters: ["admin"], group: "Broadcast" },
  { slug: "quotex-signals", name: "Quotex Signals", description: "Quotex signals — read only.", readers: ["admin", "team", "member"], posters: ["admin"], group: "Broadcast" },
  { slug: "forex-signals", name: "Forex Signals", description: "Forex signals — read only.", readers: ["admin", "team", "member"], posters: ["admin"], group: "Broadcast" },
  { slug: "public-chat", name: "Public Discussion", description: "Talk with other members.", readers: ["admin", "team", "member"], posters: ["admin", "team", "member"], group: "Community" },
  { slug: "feedback", name: "Feedback", description: "Ideas and suggestions.", readers: ["admin", "team", "member"], posters: ["admin", "team", "member"], group: "Community" },
  { slug: "complaints", name: "Complaints", description: "Report a problem.", readers: ["admin", "team", "member"], posters: ["admin", "team", "member"], group: "Community" },
  { slug: "team-updates", name: "Team Updates", description: "Instructions for the team.", readers: ["admin", "team"], posters: ["admin"], group: "Team" },
  { slug: "team-chat", name: "Team Discussion", description: "Private team discussion.", readers: ["admin", "team"], posters: ["admin", "team"], group: "Team" },
];

export const channelBySlug = (s: string) => CHANNELS.find((c) => c.slug === s);
