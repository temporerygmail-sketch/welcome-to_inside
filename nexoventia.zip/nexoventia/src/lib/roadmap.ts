// Roadmap 2K27 — the full 13-month plan, written out day by day.
// Every month and day is generated in full (no "same as previous month" shortcuts).

export type AccountId = "QX" | "EF25" | "EF10" | "EF50" | "EF100";
export type Owner = "Ismail" | "Partner" | "Pro Trader";

export const ACCOUNTS: Record<AccountId, { name: string; short: string; size: string }> = {
  QX: { name: "Quotex", short: "Quotex", size: "$10 start" },
  EF25: { name: "Eze Funded 2.5K (2-Step)", short: "EF 2.5K", size: "$2,500" },
  EF10: { name: "Eze Funded 10K (2-Step)", short: "EF 10K", size: "$10,000" },
  EF50: { name: "Eze Funded 50K (2-Step)", short: "EF 50K", size: "$50,000" },
  EF100: { name: "Eze Funded 100K (2-Step)", short: "EF 100K", size: "$100,000" },
};

export type Task = {
  key: string;
  account: AccountId;
  owner: Owner;
  title: string;
  details: string[];
  risk?: string | undefined;
  target?: string | undefined;
  withdrawal?: number | undefined;
  rest?: boolean | undefined;
};

export type Day = { day: number; weekend: boolean; tasks: Task[] };

export type Month = {
  n: number;
  title: string;
  theme: string;
  overview: string;
  rules: string[];
  accounts: { account: AccountId; owner: Owner; plan: string }[];
  results: string[];
  expectedWithdrawals: number;
  cumulative: number;
  days: Day[];
};

export const DAYS_PER_MONTH = 30;
export const isWeekend = (d: number) => (d - 1) % 7 >= 5;
const workingDays = () => Array.from({ length: DAYS_PER_MONTH }, (_, i) => i + 1).filter((d) => !isWeekend(d));

const key = (m: number, d: number, a: AccountId) => `m${m}-d${d}-${a}`;

type Builder = (m: number, d: number, wi: number) => Omit<Task, "key" | "account"> | null;
// wi = index of the working day (0-based), or -1 on weekends

function buildDays(m: number, builders: Partial<Record<AccountId, Builder>>): Day[] {
  const wds = workingDays();
  const days: Day[] = [];
  for (let d = 1; d <= DAYS_PER_MONTH; d++) {
    const wi = wds.indexOf(d);
    const tasks: Task[] = [];
    (Object.keys(builders) as AccountId[]).forEach((a) => {
      const t = builders[a]!(m, d, wi);
      if (t) tasks.push({ ...t, key: key(m, d, a), account: a });
    });
    days.push({ day: d, weekend: isWeekend(d), tasks });
  }
  return days;
}

const weekendRest = (owner: Owner, account: AccountId): Omit<Task, "key" | "account"> => ({
  owner,
  title: "Weekend — market closed, rest day",
  details: [`No trading on ${ACCOUNTS[account].short}.`, "Review the week's trades and journal notes."],
  rest: true,
});

/* ---------------- Quotex plans ---------------- */

// Month 1: fixed daily profits from the plan.
const QX_M1: Record<number, { p?: number; w?: number; note?: string }> = {
  1: { p: 3 }, 2: { p: 4 }, 3: { p: 5 }, 4: { p: 6, w: 11 },
  5: { p: 5 }, 6: { p: 6 }, 7: { p: 7, w: 13 },
  8: { p: 6 }, 9: { p: 7 }, 10: { p: 8, w: 15, note: "Use the $32 from Days 4–10 withdrawals (incl. fee and tax) to buy the Eze Funded 2.5K 2-Step account. About $7 (≈ PKR 1,800–1,900) stays with you for food and clothes." },
  11: { p: 7 }, 12: { p: 8 }, 13: { p: 9, w: 17 },
  14: { p: 8 }, 15: {}, 16: { p: 9 }, 17: { p: 10, w: 19 },
  18: { p: 9 }, 19: { p: 10 }, 20: { p: 11 }, 21: { w: 21 },
  22: { p: 10 }, 23: { p: 11 }, 24: { p: 12, w: 23 },
  25: { p: 11 }, 26: { p: 12 }, 27: { p: 13, w: 25 }, 28: {},
  29: { w: 38, note: "Month-end withdrawal. $35 stays in the Quotex account for Month 2." }, 30: {},
};

function qxMonth1(): Builder {
  let bal = 10;
  return (_m, d) => {
    const s = QX_M1[d] ?? {};
    const start = bal;
    if (s.p) bal += s.p;
    if (s.w) bal -= s.w;
    if (!s.p && !s.w)
      return { owner: "Ismail", title: "Rest day", details: [`Balance stays at $${bal}.`, "No trades today."], rest: true };
    const det: string[] = [`Opening balance: $${start}.`];
    if (s.p) det.push(`Profit target: +$${s.p} → balance $${start + s.p}.`);
    if (s.w) det.push(`Withdraw $${s.w} → closing balance $${bal}.`);
    if (d === 1) det.unshift("Deposit $10 (≈ PKR 3,000) into Quotex.");
    if (s.note) det.push(s.note);
    return {
      owner: "Ismail",
      title: s.p ? `Trade Quotex — make +$${s.p}` : `Withdraw $${s.w}`,
      details: det,
      target: s.p ? `+$${s.p}` : undefined,
      withdrawal: s.w,
    };
  };
}

// Months 2 & 3: [from, to, withdrawal]
type QxRange = [number, number, number?] | "rest";
const QX_M2: Record<number, QxRange> = {
  1: [35, 43], 2: [43, 52], 3: [52, 62, 19], 4: [43, 52], 5: [52, 62], 6: [62, 73, 21], 7: "rest",
  8: [52, 62], 9: [62, 73], 10: [73, 85, 23], 11: [62, 73], 12: [73, 85], 13: [85, 98, 46], 14: "rest",
  15: [52, 62], 16: [62, 73], 17: [73, 85, 23], 18: [62, 73], 19: [73, 85], 20: [85, 98, 36], 21: "rest",
  22: [62, 73], 23: [73, 85], 24: [85, 98, 25], 25: [73, 85], 26: [85, 98], 27: [98, 112, 62],
  28: "rest", 29: "rest", 30: "rest",
};
const QX_M3: Record<number, QxRange> = {
  1: [50, 58], 2: [58, 67], 3: [67, 77, 19], 4: [58, 67], 5: [67, 77], 6: [77, 88, 21], 7: "rest",
  8: [67, 77], 9: [77, 88], 10: [88, 100, 23], 11: [77, 88], 12: [88, 100], 13: [100, 113, 36], 14: "rest",
  15: [77, 88], 16: [88, 100], 17: [100, 113, 25], 18: [88, 100], 19: [100, 113], 20: [113, 127, 27], 21: "rest",
  22: [100, 113], 23: [113, 127], 24: [127, 142, 29], 25: [113, 127], 26: [127, 142], 27: [142, 158, 158],
  28: "rest", 29: "rest", 30: "rest",
};

function qxRange(table: Record<number, QxRange>, last: boolean): Builder {
  return (_m, d) => {
    const r = table[d] ?? "rest";
    if (r === "rest")
      return { owner: "Partner", title: "Rest day", details: ["No Quotex trades today.", "Partner rests; Ismail reviews the week."], rest: true };
    const [from, to, w] = r;
    const det = [
      `Partner trades on their own phone following Ismail's signals only.`,
      `Start of day: $${from}. Target: $${to} (+$${to - from}).`,
    ];
    if (w) det.push(`Withdraw $${w} at the end of the day.`);
    if (last && d === 27) det.push("Final Quotex day — the full balance is withdrawn. Quotex closes at $0.");
    return {
      owner: "Partner",
      title: `Quotex: $${from} → $${to}${w ? ` · withdraw $${w}` : ""}`,
      details: det,
      target: `$${from} → $${to}`,
      withdrawal: w,
    };
  };
}

/* ---------------- Eze Funded builders ---------------- */

function ef25Month1(): Builder {
  return (_m, d) => {
    if (d < 10) return null;
    if (d === 10)
      return { owner: "Ismail", title: "Buy Eze Funded 2.5K 2-Step", details: ["Pay $32 (fee + tax included) from Quotex withdrawals.", "Phase 1 target 10%, max drawdown 10%."] };
    if (isWeekend(d)) return weekendRest("Ismail", "EF25");
    if (d >= 11 && d <= 20)
      return {
        owner: "Ismail",
        title: "Phase 1 — risk $15, target $50 per trade",
        details: ["Phase 1 goal: +10% ($250) within the first 10 days (7 trading days).", "One trade: risk $15, take profit $50.", "Stop trading for the day once the trade closes."],
        risk: "$15", target: "$50",
      };
    if (d >= 22 && d <= 26)
      return {
        owner: "Ismail",
        title: "Phase 2 — reach +5% in 5–6 days",
        details: ["Phase 2 goal: +5% ($125), drawdown 10%.", "Risk $15, take profit $50 per trade.", d === 26 ? "Phase 2 should be complete — request the live account." : "Protect the drawdown; skip weak setups."],
        risk: "$15", target: "$50",
      };
    if (d === 29) return { owner: "Ismail", title: "Live account — first trade & withdrawal", details: ["Live account received (Day 26–27).", "Risk small, take the profit and withdraw $15.", "Daily withdrawals allowed, no IP rules. Live drawdown becomes 30–50%."], risk: "$10", target: "$15", withdrawal: 15 };
    if (d === 30) return { owner: "Ismail", title: "Live account — withdraw $18", details: ["Trade the live account and withdraw $18.", "Month 1 Eze Funded total withdrawal: $33 (account fee recovered)."], risk: "$10", target: "$18", withdrawal: 18 };
    return null;
  };
}

function efLiveSteady(owner: Owner, account: AccountId, opts: { risk: string; daily: number; note: string[] }): Builder {
  return (_m, d) => {
    if (isWeekend(d)) return weekendRest(owner, account);
    return {
      owner,
      title: `Live — risk ${opts.risk}, daily target $${opts.daily}`,
      details: [...opts.note, `Withdraw today's $${opts.daily} profit (daily withdrawals allowed).`],
      risk: opts.risk, target: `$${opts.daily}`, withdrawal: opts.daily,
    };
  };
}

// Evaluation then fee recovery for a newly bought account.
function efEvaluation(o: {
  account: AccountId; price: number; p1Risk: string; p1Target: string; p2Days: number;
  recRisk: string; recTarget: string; recDaily: number; recStop: number; phase1Goal: string; phase2Goal: string;
}): Builder {
  return (_m, d, wi) => {
    const a = ACCOUNTS[o.account].short;
    if (isWeekend(d)) return weekendRest("Ismail", o.account);
    if (wi < 10)
      return {
        owner: "Ismail",
        title: `${wi === 0 ? `Buy ${a} (~$${o.price}) · ` : ""}Phase 1 — risk ${o.p1Risk}, target ${o.p1Target}`,
        details: [
          ...(wi === 0 ? [`Purchase the ${ACCOUNTS[o.account].name} account for about $${o.price}.`] : []),
          `Phase 1 goal: ${o.phase1Goal} within 10 working days (working day ${wi + 1} of 10).`,
          `One trade: risk ${o.p1Risk}, take profit ${o.p1Target}.`,
          "If the target is hit early, move straight to Phase 2.",
        ],
        risk: o.p1Risk, target: o.p1Target,
      };
    if (wi < 10 + o.p2Days)
      return {
        owner: "Ismail",
        title: `Phase 2 — risk ${o.p1Risk}, target ${o.p1Target}`,
        details: [`Phase 2 goal: ${o.phase2Goal} (working day ${wi - 9} of ${o.p2Days}).`, `Same management as Phase 1: risk ${o.p1Risk}, take profit ${o.p1Target}.`, "Drawdown 10% — protect it."],
        risk: o.p1Risk, target: o.p1Target,
      };
    const recIdx = wi - 10 - o.p2Days;
    const already = recIdx * o.recDaily;
    if (already >= o.recStop)
      return { owner: "Ismail", title: "Fee recovered — rest this account", details: [`$${o.recStop} already withdrawn. No more trades on ${a} this month.`], rest: true };
    return {
      owner: "Ismail",
      title: `Live — recover fee: risk ${o.recRisk}, target ${o.recTarget}`,
      details: [`Funded account active. Withdraw $${o.recDaily} today.`, `Stop for the month once $${o.recStop} is withdrawn (so far: $${already}).`],
      risk: o.recRisk, target: o.recTarget, withdrawal: o.recDaily,
    };
  };
}

/* ---------------- Month builders ---------------- */

const partnerEF25 = (target: number, partnerCut: number, label: string): Builder => (_m, d) => {
  if (isWeekend(d)) return weekendRest("Partner", "EF25");
  return {
    owner: "Partner",
    title: `Partner runs EF 2.5K on signals — ${label}`,
    details: [
      "Partner trades this account following Ismail's signals only.",
      `Monthly target: $${target}. Partner receives $${partnerCut}, Ismail keeps $${target - partnerCut}.`,
      "Risk about $10 per trade, take ~$11–15 per day.",
    ],
    risk: "$10", target: `~$${Math.round(target / 20)}/day`,
  };
};

const ef10Steady = (owner: Owner, stop: number, extra: string[] = []): Builder => (_m, d, wi) => {
  if (isWeekend(d)) return weekendRest(owner, "EF10");
  const done = wi * 65;
  if (done >= stop) return { owner, title: "Monthly target reached — stop", details: [`$${stop} target reached. No more trades on EF 10K this month.`], rest: true };
  return {
    owner,
    title: "EF 10K — risk $20, target $60–70",
    details: [...extra, "Risk $20 per trade, daily profit target $60–70.", `Stop for the month at $${stop} (approx. so far: $${done}).`, "Withdraw the day's profit."],
    risk: "$20", target: "$60–70", withdrawal: 65,
  };
};

const ef50Live = (_m: number, d: number): Omit<Task, "key" | "account"> => {
  if (isWeekend(d)) return weekendRest("Ismail", "EF50");
  return {
    owner: "Ismail",
    title: "EF 50K — risk $50, target $150",
    details: ["This account runs every week (no rest weeks).", "Risk $50 per trade, take profit $150.", "20 working days → $2,100–2,300 for the month.", "Withdraw the day's profit."],
    risk: "$50", target: "$150", withdrawal: 110,
  };
};

const ef100Live: Builder = (_m, d) => {
  if (isWeekend(d)) return weekendRest("Ismail", "EF100");
  const week = Math.floor((d - 1) / 7) + 1;
  if (week === 2 || week >= 4)
    return { owner: "Ismail", title: "Rest week for EF 100K", details: ["Week " + week + " is a rest week for the 100K account.", "Only the 50K account is traded this week."], rest: true };
  return {
    owner: "Ismail",
    title: `EF 100K — week ${week}: risk $100, target $300`,
    details: ["Risk $100 per trade, take profit $300.", "Stop for the week at $1,000–1,200.", "Withdraw the day's profit."],
    risk: "$100", target: "$300", withdrawal: 300,
  };
};

function month1(): Month {
  return {
    n: 1, title: "Month 1 — The $10 Launch", theme: "launch",
    overview: "Start with $10 (≈ PKR 3,000) on Quotex, grow it day by day, and use the early withdrawals to buy an Eze Funded 2.5K two-step account on Day 10. Pass both phases inside the month and reach the live account.",
    rules: [
      "Quotex: follow the exact daily profit targets; never chase extra.",
      "Withdraw on the scheduled days only.",
      "Eze Funded 2.5K Phase 1: 10% target, 10% drawdown. Risk $15, target $50 per trade.",
      "Phase 2: 5% target, 10% drawdown, finish in 5–6 days.",
      "Live account: daily withdrawals allowed, no IP rules, drawdown 30–50%.",
      "Eze Funded is the trusted prop firm founded by Waqas Ahmad.",
    ],
    accounts: [
      { account: "QX", owner: "Ismail", plan: "Day-by-day profit ladder from $10" },
      { account: "EF25", owner: "Ismail", plan: "Buy Day 10, pass Phases 1 & 2, live by Day 27" },
    ],
    results: [
      "Days 1–10 Quotex withdrawals: $39 → $32 spent on Eze Funded account, $7 kept.",
      "Days 11–30 Quotex withdrawals: $105 + $38 month-end.",
      "Eze Funded live withdrawals: $33.",
      "Quotex balance carried to Month 2: $35.",
      "Total saved this month: ≈ $173.",
    ],
    expectedWithdrawals: 173, cumulative: 173,
    days: buildDays(1, { QX: qxMonth1(), EF25: ef25Month1() }),
  };
}

function month2(): Month {
  return {
    n: 2, title: "Month 2 — Partner on Quotex, Ismail on Funded", theme: "partner",
    overview: "A trusted partner (Ali or Abdulrehman) trades Quotex on their own phone using Ismail's signals. Ismail trades the Eze Funded 2.5K live account. Partners are profit-share partners, not salaried staff.",
    rules: [
      "Partner follows Ismail's signals only — no own trades.",
      "Partner profit share: 13% (agreed range 10–23%).",
      "Quotex: follow the daily ranges and withdrawals exactly.",
      "Eze Funded 2.5K live: ~$10 risk, $15 daily target, 20 of 22 market days.",
    ],
    accounts: [
      { account: "QX", owner: "Partner", plan: "Start $35, ranges from the plan" },
      { account: "EF25", owner: "Ismail", plan: "Live, $15 per day" },
    ],
    results: ["Quotex withdrawals: ≈ $255 (50$ stays in account).", "Partner 13%: ≈ $34 → you keep ≈ $220.", "Eze Funded: ≈ $200–220.", "Running total: ≈ $600."],
    expectedWithdrawals: 440, cumulative: 600,
    days: buildDays(2, { QX: qxRange(QX_M2, false), EF25: efLiveSteady("Ismail", "EF25", { risk: "$10", daily: 15, note: ["Eze Funded 2.5K live account."] }) }),
  };
}

function month3(): Month {
  return {
    n: 3, title: "Month 3 — Final Quotex Month", theme: "quotex-final",
    overview: "The last Quotex month. Partner starts at $50 and the full balance is withdrawn on Day 27. Ismail keeps the same Eze Funded management as Month 2.",
    rules: [
      "Partner follows Ismail's signals; 13% profit share.",
      "Day 27: withdraw everything — Quotex ends at $0.",
      "Eze Funded 2.5K live: ~$10 risk, $15 daily target.",
    ],
    accounts: [
      { account: "QX", owner: "Partner", plan: "Start $50 → full withdrawal Day 27" },
      { account: "EF25", owner: "Ismail", plan: "Live, $15 per day" },
    ],
    results: ["Quotex withdrawals (excluding the $50 start): ≈ $310.", "Partner 13%: ≈ $41 → you keep ≈ $270.", "Eze Funded: ≈ $230.", "Running total: ≈ $1,100."],
    expectedWithdrawals: 500, cumulative: 1100,
    days: buildDays(3, { QX: qxRange(QX_M3, true), EF25: efLiveSteady("Ismail", "EF25", { risk: "$10", daily: 15, note: ["Eze Funded 2.5K live account."] }) }),
  };
}

function month4(): Month {
  return {
    n: 4, title: "Month 4 — Buy the 10K", theme: "scale-10k",
    overview: "Buy an Eze Funded 10K two-step account (~$100). Pass Phase 1 in up to 10 working days, Phase 2 in 5–7 days, then recover the fee. The 2.5K live account runs easy all month.",
    rules: [
      "10K Phase 1 & 2: risk $60, target $200 per trade (10% target, 10% drawdown).",
      "After passing: risk $20, target $50, withdraw $50 daily, stop at $150.",
      "2.5K live: easy pace, $250 month target.",
    ],
    accounts: [
      { account: "EF10", owner: "Ismail", plan: "Buy, pass, recover $150" },
      { account: "EF25", owner: "Ismail", plan: "Live, ~$12/day, $250 month" },
    ],
    results: ["Account fee $100 recovered → back to ≈ $1,150.", "2.5K live: ≈ $250.", "Running total: ≈ $1,350–1,400."],
    expectedWithdrawals: 400, cumulative: 1375,
    days: buildDays(4, {
      EF10: efEvaluation({ account: "EF10", price: 100, p1Risk: "$60", p1Target: "$200", p2Days: 6, recRisk: "$20", recTarget: "$50", recDaily: 50, recStop: 150, phase1Goal: "+10% ($1,000)", phase2Goal: "+5% ($500)" }),
      EF25: efLiveSteady("Ismail", "EF25", { risk: "$10", daily: 12, note: ["Easy pace on the 2.5K live account.", "Month target: $250."] }),
    }),
  };
}

function month5(): Month {
  return {
    n: 5, title: "Month 5 — Two Funded Accounts", theme: "two-accounts",
    overview: "Week 1: Ismail trades the 2.5K for $60. Week 2: Ismail trades the 10K (risk $20, $50–60/day) and stops at $200. Weeks 3–4: Partner runs the 2.5K for two weeks on signals; Ismail runs the 10K calmly for ~$400.",
    rules: [
      "Week 1 (5 days): 2.5K, $60 total withdrawal.",
      "Week 2 (5 days): 10K, risk $20, $50–60/day, stop at $200.",
      "Weeks 3–4: Partner on 2.5K, target $110 → partner $20, you $90.",
      "Weeks 3–4: 10K, ~$400 over 10 working days.",
    ],
    accounts: [
      { account: "EF25", owner: "Ismail", plan: "Week 1 → then Partner weeks 3–4" },
      { account: "EF10", owner: "Ismail", plan: "Week 2 $200, weeks 3–4 $400" },
    ],
    results: ["Week 1: +$60 → $1,400.", "Week 2: +$200 → $1,600.", "Partner: +$90 → ≈ $1,700.", "10K: +$400 → ≈ $2,100."],
    expectedWithdrawals: 750, cumulative: 2100,
    days: buildDays(5, {
      EF25: (_m, d, wi) => {
        if (isWeekend(d)) return weekendRest(wi < 0 && d > 14 ? "Partner" : "Ismail", "EF25");
        if (wi < 5) return { owner: "Ismail", title: "2.5K — week 1, $12 per day", details: ["Ismail trades the 2.5K this week.", "Week goal: withdraw $60 total."], risk: "$10", target: "$12", withdrawal: 12 };
        if (wi < 10) return { owner: "Ismail", title: "2.5K resting this week", details: ["Focus is on the 10K account this week."], rest: true };
        return { owner: "Partner", title: "Partner runs 2.5K on signals", details: ["Two-week run on Ismail's signals.", "Target $110 → partner gets $20, you keep $90.", "Risk ~$8, target ~$11 per day."], risk: "$8", target: "$11" };
      },
      EF10: (_m, d, wi) => {
        if (isWeekend(d)) return weekendRest("Ismail", "EF10");
        if (wi < 5) return { owner: "Ismail", title: "10K resting this week", details: ["Week 1 is the 2.5K week."], rest: true };
        if (wi < 10) return { owner: "Ismail", title: "10K — risk $20, target $50–60", details: ["Week goal: $200, then stop for the week.", "Withdraw daily profit."], risk: "$20", target: "$50–60", withdrawal: 40 };
        return { owner: "Ismail", title: "10K — easy pace, ~$40/day", details: ["10 working days, ~$400 total.", "Risk $20 per trade."], risk: "$20", target: "$40", withdrawal: 40 };
      },
    }),
  };
}

function month6or7(n: 6 | 7): Month {
  return {
    n, title: `Month ${n} — Partner 2.5K + Ismail 10K`, theme: n === 6 ? "steady" : "repeat",
    overview: "Partner runs the 2.5K on Ismail's signals with a $220 target ($70 to partner, $150 to you). Ismail runs the 10K with $20 risk and $60–70 daily target, stopping at $850.",
    rules: [
      "Partner on 2.5K: target $220 → partner $70, you $150.",
      "10K: risk $20, daily target $60–70, stop at $850.",
      "Withdraw daily profit.",
    ],
    accounts: [
      { account: "EF25", owner: "Partner", plan: "$220 target, $150 to you" },
      { account: "EF10", owner: "Ismail", plan: "$850 month" },
    ],
    results: n === 6 ? ["Partner: +$150 → $2,250.", "10K: +$850 → ≈ $3,000."] : ["Partner: +$150.", "10K: +$850.", "Running total: ≈ $4,000."],
    expectedWithdrawals: 1000, cumulative: n === 6 ? 3000 : 4000,
    days: buildDays(n, { EF25: partnerEF25(220, 70, "$220 month"), EF10: ef10Steady("Ismail", 850) }),
  };
}

function month8(): Month {
  return {
    n: 8, title: "Month 8 — Buy the 50K", theme: "scale-50k",
    overview: "Buy an Eze Funded 50K account (~$500). Pass Phase 1 in 10 working days and Phase 2 in the next 7, then recover the fee in 5 days. Partner keeps the 2.5K and Ismail keeps the 10K on the same rules.",
    rules: [
      "50K Phases: risk $300, target $1,000 per trade.",
      "After passing: risk $70, target $150 until the fee is back, then rest.",
      "Partner 2.5K: $220 → $70 partner, $150 you.",
      "10K: risk $20, $60–70/day, stop at $850.",
    ],
    accounts: [
      { account: "EF50", owner: "Ismail", plan: "Buy, pass, recover $500" },
      { account: "EF25", owner: "Partner", plan: "$150 to you" },
      { account: "EF10", owner: "Ismail", plan: "$850" },
    ],
    results: ["After buying: $3,500.", "Partner +$150 → $3,650.", "10K +$850 → $4,500.", "50K fee recovered → ≈ $5,000."],
    expectedWithdrawals: 1500, cumulative: 5000,
    days: buildDays(8, {
      EF50: efEvaluation({ account: "EF50", price: 500, p1Risk: "$300", p1Target: "$1,000", p2Days: 7, recRisk: "$70", recTarget: "$150", recDaily: 150, recStop: 500, phase1Goal: "+10% ($5,000)", phase2Goal: "+5% ($2,500)" }),
      EF25: partnerEF25(220, 70, "$220 month"),
      EF10: ef10Steady("Ismail", 850),
    }),
  };
}

function month9or10(n: 9 | 10): Month {
  return {
    n, title: `Month ${n} — Pro Trader joins`, theme: n === 9 ? "pro-team" : "pro-repeat",
    overview: "A professional trader follows Ismail's signals on the 10K (13% share). Partner keeps the 2.5K. Ismail runs the 50K live with $50 risk and $150 target every working day.",
    rules: [
      "10K (Pro Trader): $850 month → $110 to pro, $740 to you.",
      "2.5K (Partner): $150 to you.",
      "50K (Ismail): risk $50, target $150, 20 working days, no rest weeks.",
    ],
    accounts: [
      { account: "EF10", owner: "Pro Trader", plan: "$850, 13% share" },
      { account: "EF25", owner: "Partner", plan: "$150 to you" },
      { account: "EF50", owner: "Ismail", plan: "$2,100–2,300" },
    ],
    results: n === 9 ? ["10K net $740 → $5,750.", "2.5K +$150 → $5,900.", "50K +$2,100–2,300 → ≈ $8,000+."] : ["Same rules as Month 9.", "Running total: ≈ $11,000."],
    expectedWithdrawals: 3000, cumulative: n === 9 ? 8000 : 11000,
    days: buildDays(n, {
      EF10: ef10Steady("Pro Trader", 850, ["Pro Trader follows Ismail's signals.", "13% of the month's profit goes to the Pro Trader."]),
      EF25: partnerEF25(220, 70, "$220 month"),
      EF50: (m, d) => ef50Live(m, d),
    }),
  };
}

function month11(): Month {
  return {
    n: 11, title: "Month 11 — Buy the 100K", theme: "scale-100k",
    overview: "Buy an Eze Funded 100K account (~$1,000). Phase 1 in 10 working days, Phase 2 in 7, then recover the fee in 5 days with $100 risk and $300 target. All other accounts keep the same rules.",
    rules: [
      "100K Phases: risk $600, target $2,000 per trade.",
      "After passing: risk $100, target $300 until the $1,000 fee is back.",
      "50K: risk $50, target $150, every working day.",
      "10K (Pro Trader) and 2.5K (Partner): same management.",
    ],
    accounts: [
      { account: "EF100", owner: "Ismail", plan: "Buy, pass, recover $1,000" },
      { account: "EF50", owner: "Ismail", plan: "$2,100–2,300" },
      { account: "EF10", owner: "Pro Trader", plan: "Net $740" },
      { account: "EF25", owner: "Partner", plan: "$150" },
    ],
    results: ["After the 100K fee is recovered and 2.5K adds $150: $11,150.", "10K and 50K income added.", "Running total: ≈ $15,000."],
    expectedWithdrawals: 4000, cumulative: 15000,
    days: buildDays(11, {
      EF100: efEvaluation({ account: "EF100", price: 1000, p1Risk: "$600", p1Target: "$2,000", p2Days: 7, recRisk: "$100", recTarget: "$300", recDaily: 300, recStop: 1000, phase1Goal: "+10% ($10,000)", phase2Goal: "+5% ($5,000)" }),
      EF50: (m, d) => ef50Live(m, d),
      EF10: ef10Steady("Pro Trader", 850, ["Pro Trader follows Ismail's signals (13% share)."]),
      EF25: partnerEF25(220, 70, "$220 month"),
    }),
  };
}

function month12or13(n: 12 | 13): Month {
  return {
    n, title: `Month ${n} — Full Portfolio`, theme: n === 12 ? "portfolio" : "finale",
    overview: "All four funded accounts run. The 100K trades in weeks 1 and 3 only (risk $100, target $300, stop at $1,000–1,200 per week) and rests in weeks 2 and 4. The 50K never rests.",
    rules: [
      "100K: week 1 and week 3 — risk $100, target $300, stop at $1,000–1,200. Weeks 2 and 4 rest.",
      "50K: risk $50, target $150, every working day.",
      "10K (Pro Trader): $850 month, 13% share.",
      "2.5K (Partner): $220 → $150 to you.",
    ],
    accounts: [
      { account: "EF100", owner: "Ismail", plan: "Weeks 1 & 3, $2,000–2,400" },
      { account: "EF50", owner: "Ismail", plan: "$2,100–2,300" },
      { account: "EF10", owner: "Pro Trader", plan: "Net $740" },
      { account: "EF25", owner: "Partner", plan: "$150" },
    ],
    results: ["100K: ≈ $2,000–2,400.", "50K: ≈ $2,100–2,300.", "10K net ≈ $740, 2.5K ≈ $150.", `Projected running total: ≈ $${n === 12 ? "20,000" : "25,000"}.`],
    expectedWithdrawals: 5000, cumulative: n === 12 ? 20000 : 25000,
    days: buildDays(n, {
      EF100: ef100Live,
      EF50: (m, d) => ef50Live(m, d),
      EF10: ef10Steady("Pro Trader", 850, ["Pro Trader follows Ismail's signals (13% share)."]),
      EF25: partnerEF25(220, 70, "$220 month"),
    }),
  };
}

export const ROADMAP: Month[] = [
  month1(), month2(), month3(), month4(), month5(), month6or7(6), month6or7(7),
  month8(), month9or10(9), month9or10(10), month11(), month12or13(12), month12or13(13),
];

export const TOTAL_DAYS = ROADMAP.length * DAYS_PER_MONTH;

export function dayFromStart(start: string, now = new Date()): { month: number; day: number; absolute: number } {
  const s = new Date(start + "T00:00:00");
  const diff = Math.floor((now.getTime() - s.getTime()) / 86400000);
  const abs = Math.min(Math.max(diff, 0), TOTAL_DAYS - 1);
  return { month: Math.floor(abs / DAYS_PER_MONTH) + 1, day: (abs % DAYS_PER_MONTH) + 1, absolute: abs + 1 };
}

export function tasksForAccount(month: number, day: number, account?: string | null): Task[] {
  const m = ROADMAP[month - 1];
  const d = m?.days[day - 1];
  if (!d) return [];
  return account ? d.tasks.filter((t) => t.account === account) : d.tasks;
}
