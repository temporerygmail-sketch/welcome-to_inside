import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export async function uploadMedia(userId: string, file: Blob, name: string) {
  const ext = name.includes(".") ? name.split(".").pop() : "bin";
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from("media").upload(path, file, file.type ? { contentType: file.type } : {});
  if (error) throw error;
  return path;
}

export function mediaKind(type: string): "image" | "video" | "audio" | "file" {
  if (type.startsWith("image/")) return "image";
  if (type.startsWith("video/")) return "video";
  if (type.startsWith("audio/")) return "audio";
  return "file";
}

export function useMediaUrl(path?: string | null) {
  return useQuery({
    queryKey: ["media", path],
    enabled: !!path,
    staleTime: 50 * 60_000,
    queryFn: async () => {
      if (!path) return null;
      if (path.startsWith("http")) return path;
      const { data } = await supabase.storage.from("media").createSignedUrl(path, 3600);
      return data?.signedUrl ?? null;
    },
  });
}
