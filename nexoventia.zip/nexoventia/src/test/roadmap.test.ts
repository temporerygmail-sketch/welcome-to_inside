import { describe, expect, it } from "vitest";
import { ROADMAP, tasksForAccount } from "@/lib/roadmap";

const sumW = (m: number, acc: string) =>
  ROADMAP[m - 1]!.days.flatMap((d) => d.tasks).filter((t) => t.account === acc).reduce((a, t) => a + (t.withdrawal ?? 0), 0);

describe("roadmap", () => {
  it("has 13 months of 30 days", () => {
    expect(ROADMAP).toHaveLength(13);
    ROADMAP.forEach((m) => expect(m.days).toHaveLength(30));
  });
  it("month 1 Quotex withdrawals total $182 leaving $35", () => {
    expect(sumW(1, "QX")).toBe(11 + 13 + 15 + 17 + 19 + 21 + 23 + 25 + 38);
  });
  it("month 2 Quotex withdrawals total $255", () => {
    expect(sumW(2, "QX")).toBe(255);
  });
  it("month 3 ends with full $158 withdrawal on day 27", () => {
    expect(tasksForAccount(3, 27, "QX")[0]!.withdrawal).toBe(158);
  });
  it("months 12 and 13 are fully written with all four funded accounts", () => {
    [12, 13].forEach((n) => expect(ROADMAP[n - 1]!.days[0]!.tasks.map((t) => t.account).sort()).toEqual(["EF10", "EF100", "EF25", "EF50"]));
  });
});
