import logo from "@/assets/logo.png";
import { cn } from "@/lib/utils";

export function Logo({ className, withText = true, size = 36 }: { className?: string; withText?: boolean; size?: number }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <img src={logo} alt="Nexoventia logo" width={size} height={size} className="shrink-0 object-contain" style={{ width: size, height: size }} />
      {withText && (
        <span className="font-display text-lg font-bold tracking-tight">
          Nexo<span className="text-gold-gradient">ventia</span>
        </span>
      )}
    </span>
  );
}
