import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type PromptEvent = Event & { prompt: () => Promise<void> };

export function InstallButton({ variant = "outline" }: { variant?: "outline" | "default" | "ghost" }) {
  const [evt, setEvt] = useState<PromptEvent | null>(null);
  const [open, setOpen] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    setInstalled(window.matchMedia("(display-mode: standalone)").matches);
    const h = (e: Event) => {
      e.preventDefault();
      setEvt(e as PromptEvent);
    };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);

  if (installed) return null;

  return (
    <>
      <Button
        variant={variant}
        size="sm"
        onClick={async () => {
          if (evt) {
            await evt.prompt();
            setEvt(null);
          } else setOpen(true);
        }}
      >
        <Download className="size-4" /> Install app
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Install Nexoventia</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 text-sm text-muted-foreground">
            <p><b className="text-foreground">iPhone / iPad (Safari):</b> tap the Share button, then "Add to Home Screen".</p>
            <p><b className="text-foreground">Android (Chrome):</b> open the ⋮ menu, then "Install app" or "Add to Home screen".</p>
            <p><b className="text-foreground">Windows / macOS / Linux (Chrome or Edge):</b> click the install icon at the right of the address bar, or menu → "Install Nexoventia".</p>
            <p className="text-xs">Install works on the published app link, not inside the editor preview.</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
