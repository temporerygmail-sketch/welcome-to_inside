import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { FileIcon, Lock, Mic, Paperclip, Send, Smile, Square, Sticker, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { mediaKind, uploadMedia, useMediaUrl } from "@/lib/media";
import { useMe } from "@/hooks/use-me";

type Msg = {
  id: string;
  user_id: string;
  body: string | null;
  attachment_url: string | null;
  attachment_type: string | null;
  created_at: string;
};

const EMOJIS = "😀😂🤣😊😍😎🤔😢😡👍👎👏🙏🔥💯🚀📈📉💰💵🎯✅❌⚠️⭐🏆💎🤝👀💪🎉❤️🟢🔴⏳🕐📊💡".match(/\p{Extended_Pictographic}\uFE0F?/gu) ?? [];
const STICKERS = ["🚀", "🔥", "💰", "🏆", "📈", "🎯", "💎", "🤝", "✅", "🎉", "👑", "⚡"];

type Source =
  | { kind: "channel"; channel: string }
  | { kind: "dm"; peerId: string };

export function ChatRoom({ source, canPost, readOnlyNote }: { source: Source; canPost: boolean; readOnlyNote?: string }) {
  const { data: me } = useMe();
  const qc = useQueryClient();
  const qk = ["chat", source.kind, source.kind === "channel" ? source.channel : source.peerId];
  const bottom = useRef<HTMLDivElement>(null);

  const { data: msgs = [] } = useQuery({
    queryKey: qk,
    enabled: !!me,
    queryFn: async (): Promise<Msg[]> => {
      if (source.kind === "channel") {
        const { data, error } = await supabase.from("messages").select("*").eq("channel", source.channel).order("created_at", { ascending: false }).limit(200);
        if (error) throw error;
        return (data ?? []).reverse();
      }
      const { data, error } = await supabase
        .from("direct_messages")
        .select("*")
        .or(`and(sender_id.eq.${me!.id},recipient_id.eq.${source.peerId}),and(sender_id.eq.${source.peerId},recipient_id.eq.${me!.id})`)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return (data ?? []).reverse().map((d) => ({ ...d, user_id: d.sender_id }));
    },
  });

  const ids = useMemo(() => Array.from(new Set(msgs.map((m) => m.user_id))), [msgs]);
  const { data: authors = {} } = useQuery({
    queryKey: ["authors", ids.sort().join(",")],
    enabled: ids.length > 0,
    queryFn: async () => {
      const { data } = await supabase.rpc("author_cards", { _ids: ids });
      return Object.fromEntries((data ?? []).map((a) => [a.id, a]));
    },
  });

  useEffect(() => {
    const table = source.kind === "channel" ? "messages" : "direct_messages";
    const ch = supabase
      .channel(`chat-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table }, () => qc.invalidateQueries({ queryKey: qk }))
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qk.join("|")]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  async function send(body: string | null, file?: Blob, filename?: string, typeOverride?: string) {
    if (!me) return;
    let attachment_url: string | null = null;
    let attachment_type: string | null = typeOverride ?? null;
    if (file) {
      attachment_url = await uploadMedia(me.id, file, filename ?? "file");
      attachment_type = file.type || "application/octet-stream";
    }
    const { error } =
      source.kind === "channel"
        ? await supabase.from("messages").insert({ channel: source.channel, user_id: me.id, body, attachment_url, attachment_type })
        : await supabase.from("direct_messages").insert({ sender_id: me.id, recipient_id: source.peerId, body, attachment_url, attachment_type });
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: qk });
  }

  async function remove(id: string) {
    const { error } = await supabase.from("messages").delete().eq("id", id);
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: qk });
  }

  let lastDay = "";
  return (
    <div className="panel flex h-[calc(100dvh-11rem)] flex-col overflow-hidden lg:h-[calc(100dvh-9rem)]">
      <div className="flex-1 space-y-1 overflow-y-auto p-4">
        {msgs.length === 0 && <p className="py-16 text-center text-sm text-muted-foreground">No messages yet.</p>}
        {msgs.map((m) => {
          const day = format(new Date(m.created_at), "EEEE, d MMM yyyy");
          const showDay = day !== lastDay;
          lastDay = day;
          const a = authors[m.user_id];
          const mine = m.user_id === me?.id;
          return (
            <div key={m.id}>
              {showDay && <div className="my-4 text-center text-[11px] uppercase tracking-wider text-muted-foreground">{day}</div>}
              <div className={`group flex gap-3 py-1.5 ${mine ? "flex-row-reverse" : ""}`}>
                <Avatar url={a?.avatar_url} name={a?.display_name ?? "?"} />
                <div className={`max-w-[78%] ${mine ? "items-end text-right" : ""} flex flex-col`}>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">{a?.display_name ?? "Member"}</span>
                    {a?.role === "admin" && <span className="rounded bg-gold-soft px-1.5 text-[10px] text-gold">FOUNDER</span>}
                    {a?.role === "team" && <span className="rounded bg-secondary px-1.5 text-[10px]">TEAM</span>}
                    <span>{format(new Date(m.created_at), "HH:mm")}</span>
                    {me?.role === "admin" && source.kind === "channel" && (
                      <button onClick={() => remove(m.id)} className="opacity-0 group-hover:opacity-100" aria-label="Delete message"><Trash2 className="size-3" /></button>
                    )}
                  </div>
                  <Bubble m={m} mine={mine} />
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottom} />
      </div>
      {canPost ? <Composer onSend={send} /> : (
        <div className="flex items-center justify-center gap-2 border-t border-border p-4 text-sm text-muted-foreground"><Lock className="size-4" />{readOnlyNote ?? "Only the founder can post here."}</div>
      )}
    </div>
  );
}

function Avatar({ url, name }: { url?: string | null | undefined; name: string }) {
  const { data } = useMediaUrl(url);
  return data ? (
    <img src={data} alt={name} className="size-8 shrink-0 rounded-full object-cover" />
  ) : (
    <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-semibold uppercase">{name.slice(0, 2)}</div>
  );
}

function Bubble({ m, mine }: { m: Msg; mine: boolean }) {
  const { data: url } = useMediaUrl(m.attachment_url);
  if (m.attachment_type === "sticker") return <div className="text-6xl leading-none">{m.body}</div>;
  const kind = m.attachment_type ? mediaKind(m.attachment_type) : null;
  return (
    <div className={`mt-1 inline-block space-y-2 whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 text-left text-sm ${mine ? "bg-gold-soft" : "bg-secondary"}`}>
      {url && kind === "image" && <img src={url} alt="attachment" className="max-h-80 rounded-lg" />}
      {url && kind === "video" && <video src={url} controls className="max-h-80 rounded-lg" />}
      {url && kind === "audio" && <audio src={url} controls className="max-w-full" />}
      {url && kind === "file" && <a href={url} target="_blank" rel="noreferrer" className="flex items-center gap-2 underline"><FileIcon className="size-4" />Open file</a>}
      {m.body && <div>{m.body}</div>}
    </div>
  );
}

function Composer({ onSend }: { onSend: (b: string | null, f?: Blob, n?: string, t?: string) => Promise<void> }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [rec, setRec] = useState<MediaRecorder | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function submit() {
    if (!text.trim()) return;
    setBusy(true);
    await onSend(text.trim().slice(0, 4000));
    setText("");
    setBusy(false);
  }

  async function toggleRecord(): Promise<void> {
    if (rec) {
      rec.stop();
      setRec(null);
      return;
    }
    try {
      if (!navigator.mediaDevices) throw new Error("no mic");
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const r = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      r.ondataavailable = (e) => chunks.push(e.data);
      r.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: r.mimeType || "audio/webm" });
        setBusy(true);
        await onSend(null, blob, "voice.webm");
        setBusy(false);
      };
      r.start();
      setRec(r);
    } catch {
      toast.error("Microphone not available");
    }
  }

  return (
    <div className="border-t border-border p-3">
      <div className="flex items-end gap-1.5">
        <input
          ref={fileRef}
          type="file"
          accept="image/*,video/*,audio/*,application/pdf"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (!f) return;
            if (f.size > 50 * 1024 * 1024) return void toast.error("Max file size 50MB");
            setBusy(true);
            await onSend(text.trim() || null, f, f.name);
            setText("");
            setBusy(false);
          }}
        />
        <Button size="icon" variant="ghost" onClick={() => fileRef.current?.click()} aria-label="Attach file" disabled={busy}><Paperclip /></Button>
        <Popover>
          <PopoverTrigger asChild><Button size="icon" variant="ghost" aria-label="Emoji"><Smile /></Button></PopoverTrigger>
          <PopoverContent className="grid w-72 grid-cols-8 gap-1">
            {EMOJIS.map((e) => <button key={e} className="rounded p-1 text-xl hover:bg-secondary" onClick={() => setText((t) => t + e)}>{e}</button>)}
          </PopoverContent>
        </Popover>
        <Popover>
          <PopoverTrigger asChild><Button size="icon" variant="ghost" aria-label="Sticker" className="hidden sm:inline-flex"><Sticker /></Button></PopoverTrigger>
          <PopoverContent className="grid w-64 grid-cols-4 gap-2">
            {STICKERS.map((s) => <button key={s} className="rounded-lg p-2 text-4xl hover:bg-secondary" onClick={() => onSend(s, undefined, undefined, "sticker")}>{s}</button>)}
          </PopoverContent>
        </Popover>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          placeholder="Write a message…"
          rows={1}
          className="max-h-32 min-h-10 flex-1 resize-none"
        />
        {text.trim() ? (
          <Button size="icon" onClick={submit} disabled={busy} aria-label="Send"><Send /></Button>
        ) : (
          <Button size="icon" variant={rec ? "destructive" : "default"} onClick={toggleRecord} disabled={busy} aria-label="Voice note">{rec ? <Square /> : <Mic />}</Button>
        )}
      </div>
      {rec && <p className="mt-2 text-xs text-destructive">Recording… tap stop to send.</p>}
    </div>
  );
}
