import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format, startOfDay, startOfMonth, startOfWeek, startOfYear, subDays } from "date-fns";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Signal = Tables<"signals">;
type Period = "daily" | "weekly" | "monthly" | "yearly";

export function useSignals() {
  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase
      .channel(`signals-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "signals" }, () => qc.invalidateQueries({ queryKey: ["signals"] }))
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);
  return useQuery({
    queryKey: ["signals"],
    queryFn: async () => {
      const { data, error } = await supabase.from("signals").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data;
    },
  });
}

export function computeStats(list: Signal[]) {
  const qx = list.filter((s) => s.market === "quotex");
  const fx = list.filter((s) => s.market === "forex");
  const tp = fx.filter((s) => s.status === "tp");
  const sl = fx.filter((s) => s.status === "sl");
  const qxWin = qx.filter((s) => s.status === "win").length;
  const qxLoss = qx.filter((s) => s.status === "loss").length;
  return {
    qx: { total: qx.length, win: qxWin, loss: qxLoss, active: qx.filter((s) => s.status === "active").length, rate: qxWin + qxLoss ? Math.round((qxWin / (qxWin + qxLoss)) * 100) : 0 },
    fx: {
      total: fx.length,
      active: fx.filter((s) => s.status === "active").length,
      tp: tp.length,
      sl: sl.length,
      tpPips: tp.reduce((a, s) => a + Math.abs(Number(s.pips ?? 0)), 0),
      slPips: sl.reduce((a, s) => a + Math.abs(Number(s.pips ?? 0)), 0),
    },
  };
}

const since = (p: Period) => {
  const n = new Date();
  return p === "daily" ? startOfDay(n) : p === "weekly" ? startOfWeek(n, { weekStartsOn: 1 }) : p === "monthly" ? startOfMonth(n) : startOfYear(n);
};

function Stat({ label, value, tone }: { label: string; value: string | number; tone?: "gold" | "success" | "destructive" }) {
  const c = tone === "success" ? "text-success" : tone === "destructive" ? "text-destructive" : tone === "gold" ? "text-gold" : "text-foreground";
  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`num mt-1 text-2xl font-semibold ${c}`}>{value}</div>
    </div>
  );
}

export function SignalStats({ compact = false }: { compact?: boolean }) {
  const { data = [] } = useSignals();
  const [period, setPeriod] = useState<Period>("monthly");
  const filtered = useMemo(() => data.filter((s) => new Date(s.created_at) >= since(period)), [data, period]);
  const st = computeStats(filtered);
  const all = computeStats(data);

  const chart = useMemo(() => {
    const days = Array.from({ length: 14 }, (_, i) => startOfDay(subDays(new Date(), 13 - i)));
    return days.map((d) => {
      const next = new Date(d.getTime() + 86400000);
      const inDay = data.filter((s) => new Date(s.created_at) >= d && new Date(s.created_at) < next);
      const c = computeStats(inDay);
      return { day: format(d, "d MMM"), wins: c.qx.win + c.fx.tp, losses: c.qx.loss + c.fx.sl };
    });
  }, [data]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">Signal performance</h2>
        <div className="flex rounded-lg border border-border p-0.5 text-xs">
          {(["daily", "weekly", "monthly", "yearly"] as Period[]).map((p) => (
            <button key={p} onClick={() => setPeriod(p)} className={`rounded-md px-3 py-1.5 capitalize ${period === p ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>{p}</button>
          ))}
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="panel p-4">
          <div className="mb-3 flex items-center justify-between"><span className="font-semibold">Quotex</span><span className="num text-xs text-muted-foreground">All-time {all.qx.total}</span></div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="Signals" value={st.qx.total} />
            <Stat label="Wins" value={st.qx.win} tone="success" />
            <Stat label="Losses" value={st.qx.loss} tone="destructive" />
            <Stat label="Win rate" value={`${st.qx.rate}%`} tone="gold" />
          </div>
        </div>
        <div className="panel p-4">
          <div className="mb-3 flex items-center justify-between"><span className="font-semibold">Forex</span><span className="num text-xs text-muted-foreground">All-time {all.fx.total}</span></div>
          <div className="grid grid-cols-3 gap-2">
            <Stat label="Signals" value={st.fx.total} />
            <Stat label="Active" value={st.fx.active} tone="gold" />
            <Stat label="TP hit" value={st.fx.tp} tone="success" />
            <Stat label="SL hit" value={st.fx.sl} tone="destructive" />
            <Stat label="TP pips" value={`+${st.fx.tpPips}`} tone="success" />
            <Stat label="SL pips" value={`−${st.fx.slPips}`} tone="destructive" />
          </div>
        </div>
      </div>
      {!compact && (
        <div className="panel p-4">
          <div className="mb-2 text-sm font-semibold">Last 14 days — wins vs losses</div>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={chart}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis allowDecimals={false} stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Bar dataKey="wins" fill="var(--success)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="losses" fill="var(--destructive)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}

export function SignalRow({ s }: { s: Signal }) {
  const tone = s.status === "win" || s.status === "tp" ? "text-success" : s.status === "loss" || s.status === "sl" ? "text-destructive" : "text-gold";
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border py-3 last:border-0">
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium">{s.pair}</span>
          <span className="rounded bg-secondary px-1.5 text-[10px] uppercase">{s.market}</span>
          <span className="num text-xs text-muted-foreground">{s.direction}</span>
        </div>
        <div className="num mt-0.5 truncate text-xs text-muted-foreground">
          {s.entry != null && `Entry ${s.entry} · `}
          {s.take_profit != null && `TP ${s.take_profit} · `}
          {s.stop_loss != null && `SL ${s.stop_loss} · `}
          {s.expiry && `${s.expiry} · `}
          {format(new Date(s.created_at), "d MMM HH:mm")}
        </div>
      </div>
      <div className={`num shrink-0 text-sm font-semibold uppercase ${tone}`}>
        {s.status}
        {s.pips != null && s.market === "forex" && s.status !== "active" ? ` ${s.status === "tp" ? "+" : "−"}${Math.abs(Number(s.pips))}p` : ""}
      </div>
    </div>
  );
}
