import { useEffect, useState } from "react";

/** Fixed counter that shows which numbered section is on screen (1,2,3… scrolling down, …3,2,1 scrolling up). */
export function SectionCounter({ ids }: { ids: string[] }) {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(ids.indexOf(e.target.id));
        });
      },
      { rootMargin: "-45% 0px -45% 0px" },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [ids]);

  return (
    <div className="pointer-events-none fixed right-4 top-1/2 z-30 hidden -translate-y-1/2 flex-col items-center gap-3 md:flex">
      {ids.map((id, i) => (
        <a
          key={id}
          href={`#${id}`}
          className={`pointer-events-auto num text-xs transition-all ${i === active ? "scale-125 text-gold" : "text-muted-foreground/50"}`}
        >
          {String(i + 1).padStart(2, "0")}
        </a>
      ))}
      <div className="mt-1 h-16 w-px bg-border">
        <div className="w-px bg-gold transition-all duration-500" style={{ height: `${((active + 1) / ids.length) * 100}%` }} />
      </div>
    </div>
  );
}
