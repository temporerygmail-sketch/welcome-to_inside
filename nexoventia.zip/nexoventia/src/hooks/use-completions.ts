import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useCompletions() {
  return useQuery({
    queryKey: ["completions"],
    queryFn: async () => {
      const { data, error } = await supabase.from("task_completions").select("*");
      if (error) throw error;
      return Object.fromEntries((data ?? []).map((c) => [c.task_key, c]));
    },
  });
}
