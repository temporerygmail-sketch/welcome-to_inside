<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Roadmap content lives in src/lib/roadmap.ts as generated data; task keys `m{month}-d{day}-{account}` are stored in task_completions, so never change the key format (locked ticks would detach).
- Roles come only from public.user_roles, assigned by the handle_new_user trigger (admin email / team code); never trust client-side role checks for data access.
- Journal ticks are insert-only (no update/delete policies) so they stay locked forever.
- Media bucket is private; display files via signed URLs (useMediaUrl).
