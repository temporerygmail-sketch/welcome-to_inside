
create type public.app_role as enum ('admin','team','member');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  first_name text,
  last_name text,
  username text unique,
  avatar_url text,
  age int,
  phone text,
  deposit_min numeric,
  deposit_max numeric,
  assigned_account text,
  blocked boolean not null default false,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_active(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = _user_id and blocked = false)
$$;

create policy "own roles or admin" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create policy "read own or admin" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "update own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
create policy "admin update" on public.profiles for update to authenticated
  using (public.has_role(auth.uid(),'admin'));

create or replace function public.protect_profile_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(),'admin') then
    new.blocked := old.blocked;
    new.email := old.email;
  end if;
  return new;
end $$;
create trigger protect_profile before update on public.profiles
  for each row execute function public.protect_profile_fields();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  code text := lower(trim(coalesce(m->>'team_code','')));
  r public.app_role;
begin
  insert into public.profiles (id, email, first_name, last_name, username, age, phone, deposit_min, deposit_max, assigned_account)
  values (
    new.id, new.email,
    m->>'first_name', m->>'last_name',
    nullif(m->>'username',''),
    case when coalesce(m->>'age','') ~ '^[0-9]+$' then (m->>'age')::int end,
    m->>'phone',
    case when coalesce(m->>'deposit_min','') ~ '^[0-9.]+$' then (m->>'deposit_min')::numeric end,
    case when coalesce(m->>'deposit_max','') ~ '^[0-9.]+$' then (m->>'deposit_max')::numeric end,
    case when code = 'nexoventia' then nullif(m->>'assigned_account','') else null end
  );
  if lower(new.email) = 'ismailtraderofficial@gmail.com' then r := 'admin';
  elsif code = 'nexoventia' then r := 'team';
  else r := 'member';
  end if;
  insert into public.user_roles (user_id, role) values (new.id, r);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create table public.app_settings (
  id int primary key default 1 check (id = 1),
  share_tasks boolean not null default false,
  roadmap_start date not null default current_date,
  updated_at timestamptz not null default now()
);
grant select, update on public.app_settings to authenticated;
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;
create policy "all read settings" on public.app_settings for select to authenticated using (true);
create policy "admin edits settings" on public.app_settings for update to authenticated using (public.has_role(auth.uid(),'admin'));
insert into public.app_settings (id) values (1);

create table public.task_completions (
  task_key text primary key,
  completed_by uuid not null,
  actual_balance numeric,
  note text,
  completed_at timestamptz not null default now()
);
grant select, insert on public.task_completions to authenticated;
grant all on public.task_completions to service_role;
alter table public.task_completions enable row level security;
create policy "read completions" on public.task_completions for select to authenticated
  using (public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'team'));
create policy "admin locks" on public.task_completions for insert to authenticated
  with check (public.has_role(auth.uid(),'admin') and completed_by = auth.uid());

create table public.task_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  task_key text not null,
  account text not null,
  balance numeric not null,
  screenshot_url text,
  note text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  unique (user_id, task_key)
);
grant select, insert, update on public.task_submissions to authenticated;
grant all on public.task_submissions to service_role;
alter table public.task_submissions enable row level security;
create policy "own or admin read subs" on public.task_submissions for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "team submits" on public.task_submissions for insert to authenticated
  with check (user_id = auth.uid() and public.has_role(auth.uid(),'team') and public.is_active(auth.uid()) and status = 'pending');
create policy "admin reviews" on public.task_submissions for update to authenticated
  using (public.has_role(auth.uid(),'admin'));

create table public.signals (
  id uuid primary key default gen_random_uuid(),
  market text not null check (market in ('quotex','forex')),
  pair text not null,
  direction text not null,
  entry numeric,
  take_profit numeric,
  stop_loss numeric,
  expiry text,
  status text not null default 'active',
  pips numeric,
  note text,
  created_at timestamptz not null default now(),
  closed_at timestamptz
);
grant select, insert, update, delete on public.signals to authenticated;
grant all on public.signals to service_role;
alter table public.signals enable row level security;
create policy "all read signals" on public.signals for select to authenticated using (true);
create policy "admin writes signals" on public.signals for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create or replace function public.can_read_channel(_ch text)
returns boolean language sql stable security definer set search_path = public as $$
  select case
    when public.has_role(auth.uid(),'admin') then true
    when _ch in ('team-chat','team-updates') then public.has_role(auth.uid(),'team')
    else true end
$$;
create or replace function public.can_post_channel(_ch text)
returns boolean language sql stable security definer set search_path = public as $$
  select case
    when not public.is_active(auth.uid()) then false
    when public.has_role(auth.uid(),'admin') then true
    when _ch in ('quotex-signals','forex-signals','updates','team-updates') then false
    when _ch = 'team-chat' then public.has_role(auth.uid(),'team')
    when _ch in ('public-chat','feedback','complaints') then true
    else false end
$$;

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  channel text not null,
  user_id uuid not null,
  body text,
  attachment_url text,
  attachment_type text,
  created_at timestamptz not null default now()
);
create index on public.messages (channel, created_at);
grant select, insert, delete on public.messages to authenticated;
grant all on public.messages to service_role;
alter table public.messages enable row level security;
create policy "read channel" on public.messages for select to authenticated using (public.can_read_channel(channel));
create policy "post channel" on public.messages for insert to authenticated
  with check (user_id = auth.uid() and public.can_post_channel(channel));
create policy "admin deletes" on public.messages for delete to authenticated using (public.has_role(auth.uid(),'admin'));

create or replace function public.author_cards(_ids uuid[])
returns table (id uuid, display_name text, avatar_url text, role text)
language sql stable security definer set search_path = public as $$
  select p.id, coalesce(nullif(p.username,''), p.first_name, 'Member'), p.avatar_url,
    (select ur.role::text from public.user_roles ur where ur.user_id = p.id
      order by case ur.role when 'admin' then 0 when 'team' then 1 else 2 end limit 1)
  from public.profiles p where p.id = any(_ids)
$$;
grant execute on function public.author_cards(uuid[]) to authenticated;

create or replace function public.admin_id()
returns uuid language sql stable security definer set search_path = public as $$
  select user_id from public.user_roles where role = 'admin' limit 1
$$;
grant execute on function public.admin_id() to authenticated;

create table public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null,
  recipient_id uuid not null,
  body text,
  attachment_url text,
  attachment_type text,
  created_at timestamptz not null default now()
);
create index on public.direct_messages (sender_id, recipient_id, created_at);
grant select, insert on public.direct_messages to authenticated;
grant all on public.direct_messages to service_role;
alter table public.direct_messages enable row level security;
create policy "read own dms" on public.direct_messages for select to authenticated
  using (sender_id = auth.uid() or recipient_id = auth.uid());
create policy "send dm to/from admin" on public.direct_messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_active(auth.uid())
    and (public.has_role(auth.uid(),'admin') or public.has_role(recipient_id,'admin')));

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.direct_messages;
alter publication supabase_realtime add table public.signals;

create policy "media read auth" on storage.objects for select to authenticated using (bucket_id = 'media');
create policy "media upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
